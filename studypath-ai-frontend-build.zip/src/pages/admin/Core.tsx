import { Brain, Download, FileText, GraduationCap, KeyRound, RotateCcw, School, Users } from "lucide-react";
import { useRef } from "react";
import { ActivityChart, DistributionChart, FactorBarCard } from "../../components/charts";
import { Card, Pill, SectionHead, StatCard, cn } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, adminSeed, latestPredictionFor, notifications, students, teachers } from "../../data";
import { riskCategory } from "../../lib/ai";
import { useEnterStagger } from "../../lib/hooks";
import { useApp, useAuth } from "../../store";

function downloadCSV(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

export function AdminDashboard() {
  const scopeRef = useRef<HTMLDivElement>(null);
  const preds = students.map((s) => latestPredictionFor(s.id)!).filter(Boolean);
  const avg = preds.reduce((a, p) => a + p.predictedPct, 0) / preds.length;
  const bands = [
    { label: "On track", color: "#16A34A", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "success").length },
    { label: "Attention", color: "#D97706", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "warning").length },
    { label: "At risk", color: "#DC2626", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "danger").length },
  ];
  useEnterStagger(scopeRef, ".stat-card, .dash-card");

  return (
    <div ref={scopeRef}>
      <SectionHead title="Admin dashboard" desc="Platform-wide pulse across classes and predictions." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <StatCard icon={GraduationCap} label="Students" value={students.length * 30} tone="accent" sub="across 3 branches" />
        <StatCard icon={Users} label="Teachers" value={teachers.length * 9} tone="success" />
        <StatCard icon={School} label="Classes" value={adminSeed.classes.length * 4} tone="dark" />
        <StatCard icon={Brain} label="Avg predicted" value={Math.round(avg * 10) / 10} decimals={1} suffix="%" tone={avg < 55 ? "danger" : "success"} sub="model E46_V1" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="dash-card"><DistributionChart data={bands} /></div>
        <div className="dash-card">
          <ActivityChart data={[
            { label: "Mon", verified: 12, submitted: 4 }, { label: "Tue", verified: 9, submitted: 6 },
            { label: "Wed", verified: 7, submitted: 8 }, { label: "Thu", verified: 14, submitted: 3 },
            { label: "Fri", verified: 10, submitted: 5 }, { label: "Sat", verified: 4, submitted: 1 }, { label: "Sun", verified: 6, submitted: 2 },
          ]} />
        </div>
      </div>
      <Card className="dash-card p-5 mt-5">
        <h3 className="font-display text-[15px] font-semibold mb-3">System activity</h3>
        <div className="space-y-2.5">
          {notifications.filter((n) => n.audience === "admin").concat(notifications.filter((n) => n.audience !== "admin").slice(0, 2)).map((n) => (
            <div key={n.id} className="flex items-center gap-3 text-[13px]">
              <span className={cn("w-2 h-2 rounded-full shrink-0", n.kind === "success" ? "bg-[var(--success)]" : n.kind === "warning" ? "bg-[var(--warning)]" : n.kind === "danger" ? "bg-[var(--danger)]" : "bg-[var(--accent)]")} />
              <span className="font-medium">{n.title}</span>
              <span className="text-[var(--text-muted)] truncate">— {n.body}</span>
              <span className="ml-auto text-[11px] text-[var(--text-muted)] shrink-0">{n.time}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

export function AdminAnalytics() {
  const preds = students.map((s) => latestPredictionFor(s.id)!).filter(Boolean);
  const verified = preds.filter((p) => p.dataStatus === "verified").length;
  return (
    <div>
      <SectionHead title="Prediction Analytics" desc="Model E46_V1 output quality and coverage." right={<Pill tone="dark"><Brain size={11} /> E46_V1 · features v3</Pill>} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <StatCard icon={Brain} label="Predictions run" value={preds.length * 41} tone="accent" sub="lifetime" />
        <StatCard icon={FileText} label="Verified-data runs" value={verified * 38} tone="success" />
        <StatCard icon={FileText} label="Unverified runs" value={(preds.length - verified) * 38} tone="warning" />
        <StatCard icon={GraduationCap} label="Students covered" value={students.length * 30} tone="dark" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <DistributionChart data={[
          { label: "On track", color: "#16A34A", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "success").length },
          { label: "Attention", color: "#D97706", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "warning").length },
          { label: "At risk", color: "#DC2626", count: preds.filter((p) => riskCategory(p.predictedPct).tone === "danger").length },
        ]} />
        <FactorBarCard data={FACTOR_KEYS.map((k) => ({ label: FACTOR_LABELS[k], value: Math.round(students.reduce((a, s) => a + s.factors[k], 0) / students.length) }))} title="Institutional factor averages" sub="Inputs feeding the model" />
      </div>
    </div>
  );
}

export function AdminReports() {
  const exportAll = (kind: "students" | "predictions" | "users") => {
    if (kind === "students")
      downloadCSV("students.csv", [["Name", "Roll", "Class", "Branch", "Semester"], ...students.map((s) => [s.name, s.roll, s.className, s.branch, s.semester])]);
    else if (kind === "predictions")
      downloadCSV("predictions.csv", [["Student", "Predicted %", "Marks", "Data status", "Model"], ...students.map((s) => { const p = latestPredictionFor(s.id)!; return [s.name, p.predictedPct, p.predictedMarks, p.dataStatus, p.modelVersion]; })]);
    else downloadCSV("users.csv", [["Name", "Email", "Role", "Status"], ...adminSeed.users.map((u) => [u.name, u.email, u.role, u.status])]);
  };
  const items = [
    { k: "students" as const, t: "Student register", d: "Full enrolment list with class and branch." },
    { k: "predictions" as const, t: "Prediction export", d: "Latest E46_V1 output per student, with data status." },
    { k: "users" as const, t: "User directory", d: "All accounts with roles and status." },
  ];
  return (
    <div>
      <SectionHead title="Reports" desc="Institutional exports for records and audits." />
      <div className="grid sm:grid-cols-3 gap-4 max-w-4xl">
        {items.map((i) => (
          <Card key={i.k} hover className="p-5">
            <span className="w-10 h-10 rounded-xl bg-[#f0f2f6] text-[var(--text-muted)] grid place-items-center"><FileText size={17} /></span>
            <h3 className="font-display text-[14.5px] font-semibold mt-3">{i.t}</h3>
            <p className="text-[12px] text-[var(--text-muted)] mt-1 leading-5">{i.d}</p>
            <button className="btn btn-secondary btn-sm mt-4" onClick={() => exportAll(i.k)}><Download size={13} /> Export CSV</button>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function AdminSettings() {
  const apiKey = useApp((s) => s.apiKey);
  const setApiKey = useApp((s) => s.setApiKey);
  const resetData = useApp((s) => s.resetData);
  const logout = useAuth((s) => s.logout);
  return (
    <div>
      <SectionHead title="Settings" desc="Platform configuration." />
      <div className="grid lg:grid-cols-2 gap-5 max-w-4xl">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3"><KeyRound size={16} className="text-[var(--text-muted)]" /><h3 className="font-display text-[15px] font-semibold">AI Gateway key</h3></div>
          <p className="text-[12.5px] text-[var(--text-muted)] mb-3">Used by teachers when generating roadmap drafts. Held in memory only — never hardcoded, never persisted. Production must proxy this through a backend.</p>
          <input className="input" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-…" />
          <div className="mt-4 rounded-xl bg-[#f7f8fa] border border-[var(--border)] p-3.5 text-[12.5px]">
            <div className="font-semibold mb-1">ML model</div>
            <div className="text-[var(--text-muted)]">E46_V1 · feature set v3 · numeric predictions only, no confidence scores, friendly factor labels enforced.</div>
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-display text-[15px] font-semibold mb-3">Maintenance</h3>
          <p className="text-[12.5px] text-[var(--text-muted)] mb-4">Restore the original seed data or end this demo session.</p>
          <div className="flex gap-2">
            <button className="btn btn-secondary" onClick={resetData}><RotateCcw size={14} /> Reset demo data</button>
            <button className="btn btn-danger" onClick={logout}>Sign out</button>
          </div>
        </Card>
      </div>
    </div>
  );
}
