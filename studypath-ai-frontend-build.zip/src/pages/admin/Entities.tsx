import { Pencil, Plus, Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { Avatar, Card, Field, Modal, SectionHead } from "../../components/ui";
import { adminSeed, students, teachers } from "../../data";
import { useRowStagger } from "../../lib/hooks";

interface Col { key: string; label: string; numeric?: boolean }
type Row = Record<string, string | number>;

function EntityTable({ title, desc, columns, seed }: { title: string; desc: string; columns: Col[]; seed: Row[] }) {
  const [rows, setRows] = useState<Row[]>(seed);
  const [editing, setEditing] = useState<Row | null>(null);
  const [isNew, setIsNew] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useRowStagger(ref, [rows.length]);

  const save = () => {
    if (!editing) return;
    if (isNew) setRows((r) => [...r, { ...editing, id: `row_${Date.now()}` }]);
    else setRows((r) => r.map((x) => (x.id === editing.id ? editing : x)));
    setEditing(null);
  };

  return (
    <div>
      <SectionHead title={title} desc={desc} right={
        <button className="btn btn-primary" onClick={() => { setIsNew(true); setEditing(Object.fromEntries(columns.map((c) => [c.key, c.numeric ? 0 : ""]))); }}>
          <Plus size={15} /> Add {title.toLowerCase().replace(/s$/, "")}
        </button>
      } />
      <Card className="p-0 overflow-hidden">
        <div ref={ref} className="overflow-x-auto scroll-thin">
          <table className="table">
            <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}<th /></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={String(r.id)} className="table-row">
                  {columns.map((c, i) => (
                    <td key={c.key} className={c.numeric ? "tabular-nums" : undefined}>
                      {i === 0 ? (
                        <div className="flex items-center gap-2.5">
                          <Avatar name={String(r[c.key])} color={["#2563EB", "#16A34A", "#D97706", "#7C3AED", "#0EA5E9"][Number(String(r.id).charCodeAt(0)) % 5]} size={28} />
                          <span className="font-semibold">{String(r[c.key])}</span>
                        </div>
                      ) : String(r[c.key])}
                    </td>
                  ))}
                  <td>
                    <div className="flex justify-end gap-1">
                      <button className="btn btn-ghost btn-icon" onClick={() => { setIsNew(false); setEditing({ ...r }); }} aria-label="Edit"><Pencil size={14} /></button>
                      <button className="btn btn-ghost btn-icon text-[var(--danger)]" onClick={() => setRows((x) => x.filter((y) => y.id !== r.id))} aria-label="Delete"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={isNew ? `Add ${title.toLowerCase().replace(/s$/, "")}` : "Edit record"}
        footer={<><button className="btn btn-secondary" onClick={() => setEditing(null)}>Cancel</button><button className="btn btn-primary" onClick={save}>Save</button></>}>
        <div className="grid sm:grid-cols-2 gap-4">
          {columns.map((c) => (
            <Field key={c.key} label={c.label}>
              <input
                className="input"
                type={c.numeric ? "number" : "text"}
                value={String(editing?.[c.key] ?? "")}
                onChange={(e) => setEditing((p) => (p ? { ...p, [c.key]: c.numeric ? Number(e.target.value) || 0 : e.target.value } : p))}
              />
            </Field>
          ))}
        </div>
      </Modal>
    </div>
  );
}

export function AdminUsers() {
  return <EntityTable title="Users" desc="Every account on the platform." seed={adminSeed.users}
    columns={[{ key: "name", label: "Name" }, { key: "email", label: "Email" }, { key: "role", label: "Role" }, { key: "status", label: "Status" }]} />;
}

export function AdminStudents() {
  return <EntityTable title="Students" desc="All enrolled students across branches." seed={students.map((s) => ({ id: s.id, name: s.name, roll: s.roll, class: s.className, branch: s.branch, semester: s.semester }))}
    columns={[{ key: "name", label: "Name" }, { key: "roll", label: "Roll" }, { key: "class", label: "Class" }, { key: "branch", label: "Branch" }, { key: "semester", label: "Sem", numeric: true }]} />;
}

export function AdminTeachers() {
  return <EntityTable title="Teachers" desc="Faculty accounts and assignments." seed={teachers.map((t) => ({ id: t.id, name: t.name, role: t.role === "class_teacher" ? "Class Teacher" : "Subject Teacher", assignment: t.className ?? t.subjects.join(", ") }))}
    columns={[{ key: "name", label: "Name" }, { key: "role", label: "Role" }, { key: "assignment", label: "Assignment" }]} />;
}

export function AdminClasses() {
  return <EntityTable title="Classes" desc="Sections with class teachers and strength." seed={adminSeed.classes}
    columns={[{ key: "name", label: "Class" }, { key: "branch", label: "Branch" }, { key: "semester", label: "Sem", numeric: true }, { key: "teacher", label: "Class Teacher" }, { key: "strength", label: "Strength", numeric: true }]} />;
}

export function AdminBranches() {
  return <EntityTable title="Branches" desc="Departments and heads." seed={adminSeed.branches}
    columns={[{ key: "code", label: "Code" }, { key: "name", label: "Name" }, { key: "hod", label: "HOD" }, { key: "classes", label: "Classes", numeric: true }]} />;
}

export function AdminSemesters() {
  return <EntityTable title="Semesters" desc="Active academic terms." seed={adminSeed.semesters}
    columns={[{ key: "number", label: "Semester", numeric: true }, { key: "branch", label: "Branch" }, { key: "students", label: "Students", numeric: true }, { key: "active", label: "Active" }]} />;
}

export function AdminSubjects() {
  return <EntityTable title="Subjects" desc="Course catalogue with ownership." seed={adminSeed.subjects}
    columns={[{ key: "code", label: "Code" }, { key: "name", label: "Subject" }, { key: "branch", label: "Branch" }, { key: "semester", label: "Sem", numeric: true }, { key: "teacher", label: "Teacher" }]} />;
}
