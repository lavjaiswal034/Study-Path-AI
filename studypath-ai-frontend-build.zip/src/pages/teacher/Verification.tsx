import { Bot, ShieldCheck } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Avatar, Card, EmptyState, Modal, Pill, SectionHead, TASK_STATUS } from "../../components/ui";
import { students } from "../../data";
import { aiSuggestion } from "../../lib/ai";
import { useRowStagger } from "../../lib/hooks";
import { allTasks, permissions, useApp, useAuth } from "../../store";
import type { RoadmapTask } from "../../types";

export default function TeacherVerification() {
  const role = useAuth((s) => s.role);
  const roadmaps = useApp((s) => s.roadmaps);
  const submissions = useApp((s) => s.submissions);
  const setTaskStatus = useApp((s) => s.setTaskStatus);
  const perm = permissions(role);
  const ref = useRef<HTMLDivElement>(null);

  const queue = useMemo(
    () => allTasks(roadmaps).filter(({ task, roadmap }) => task.status === "submitted" && perm.scopeSubject(task.subject) && perm.scopeStudents(students.find((s) => s.id === roadmap.studentId)!)),
    [roadmaps, perm],
  );

  const [review, setReview] = useState<{ task: RoadmapTask; studentId: string } | null>(null);
  const [feedback, setFeedback] = useState("");
  const [marks, setMarks] = useState(8);
  const [outOf, setOutOf] = useState(10);
  const [decision, setDecision] = useState<"verified" | "needs_revision">("verified");

  useRowStagger(ref, [queue.length]);

  const openReview = (task: RoadmapTask, studentId: string) => {
    setReview({ task, studentId });
    setFeedback("");
    setMarks(8); setOutOf(10);
    setDecision("verified");
  };

  const submit = () => {
    if (!review) return;
    setTaskStatus(review.task.id, decision, {
      teacherFeedback: feedback.trim() || (decision === "verified" ? "Verified — good work." : "Please revise and resubmit."),
      marks: decision === "verified" ? { awarded: marks, outOf } : undefined,
    });
    setReview(null);
  };

  return (
    <div>
      <SectionHead title="Verification" desc={perm.verifyAny ? "Review submissions across your class." : "Review submissions for your subject only."} right={<Pill tone="warning">{queue.length} awaiting</Pill>} />

      <div ref={ref} className="space-y-3 max-w-4xl">
        {queue.length === 0 && <EmptyState icon={ShieldCheck} title="Queue is clear" desc="No submitted tasks waiting for review in your scope right now." />}
        {queue.map(({ task, roadmap }) => {
          const st = students.find((s) => s.id === roadmap.studentId)!;
          return (
            <Card key={task.id} hover className="table-row p-4">
              <div className="flex items-center gap-3">
                <Avatar name={st.name} color={st.color} size={38} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-[13.5px]">{task.title}</span>
                    <Pill tone={TASK_STATUS.submitted.tone}>Submitted</Pill>
                  </div>
                  <div className="text-[12px] text-[var(--text-muted)] mt-0.5">{st.name} · {task.subject} · {task.type} · {task.estimatedMinutes} min</div>
                </div>
                <button className="btn btn-primary btn-sm" onClick={() => openReview(task, st.id)}>Review</button>
              </div>
            </Card>
          );
        })}
      </div>

      <Modal
        open={!!review}
        onClose={() => setReview(null)}
        title={review ? `Review — ${review.task.title}` : ""}
        wide
        footer={<>
          <button className="btn btn-secondary" onClick={() => setReview(null)}>Cancel</button>
          <button className="btn btn-primary" onClick={submit}><ShieldCheck size={15} /> {decision === "verified" ? "Verify task" : "Return for revision"}</button>
        </>}
      >
        {review && (
          <div className="space-y-5">
            <div>
              <div className="label">Student submission</div>
              <div className="rounded-xl bg-[#f7f8fa] border border-[var(--border)] p-4 text-[13px] leading-6 text-[#3F4550]">
                {submissions[review.task.id] ?? "The student submitted this task without additional notes."}
              </div>
            </div>

            <div className="rounded-xl border border-[#D7E3FF] bg-[var(--accent-soft)] p-4">
              <div className="flex items-center gap-1.5 text-[12px] font-bold text-[var(--accent)] mb-1.5"><Bot size={14} /> AI Gateway suggestion · suggestion only</div>
              <p className="text-[12.5px] leading-5 text-[#33509E]">{aiSuggestion(review.task.title, review.task.type)}</p>
            </div>

            <div>
              <label className="label">Your feedback</label>
              <textarea className="textarea" rows={3} value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="What should the student know?" />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <div className="label">Decision</div>
                <div className="space-y-2">
                  {(["verified", "needs_revision"] as const).map((d) => (
                    <label key={d} className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-colors ${decision === d ? "border-[var(--accent)] bg-[var(--accent-soft)]" : "border-[var(--border)]"}`}>
                      <input type="radio" name="decision" checked={decision === d} onChange={() => setDecision(d)} className="accent-[var(--accent)]" />
                      <span className="text-[13px] font-semibold">{d === "verified" ? "Verified" : "Needs revision"}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Marks {decision === "verified" ? "" : "(ignored for revisions)"}</div>
                <div className="flex items-center gap-2">
                  <input type="number" min={0} max={outOf} className="input" value={marks} onChange={(e) => setMarks(Number(e.target.value) || 0)} disabled={decision !== "verified"} aria-label="Marks awarded" />
                  <span className="text-[var(--text-muted)]">/</span>
                  <input type="number" min={1} className="input" value={outOf} onChange={(e) => setOutOf(Number(e.target.value) || 10)} disabled={decision !== "verified"} aria-label="Out of" />
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
