import { BookOpen, Eye, TrendingUp, Users } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { DistributionChart, FactorBarCard } from "../../components/charts";
import { Avatar, Card, Modal, Pill, ProgressBar, SectionHead } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, SUBJECTS, latestPredictionFor, students } from "../../data";
import { riskCategory } from "../../lib/ai";
import { useRowStagger } from "../../lib/hooks";
import { permissions, publishedForStudent, useApp, useAuth } from "../../store";
import type { Student } from "../../types";
// (cn intentionally not needed here)

export function TeacherStudents() {
  const role = useAuth((s) => s.role);
  const roadmaps = useApp((s) => s.roadmaps);
  const perm = permissions(role);
  const scoped = useMemo(() => students.filter(perm.scopeStudents), [perm]);
  const [view, setView] = useState<Student | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  useRowStagger(ref, []);

  return (
    <div>
      <SectionHead title="Students" desc={role === "class_teacher" ? "Everyone in CSE-3A." : "Students taking your subject."} />
      <Card className="p-0 overflow-hidden">
        <div ref={ref} className="overflow-x-auto scroll-thin">
          <table className="table">
            <thead><tr><th>Student</th><th>Class</th><th>Attendance</th><th>Predicted</th><th>Risk</th><th>Data</th><th /></tr></thead>
            <tbody>
              {scoped.map((s) => {
                const p = latestPredictionFor(s.id);
                const risk = p ? riskCategory(p.predictedPct) : null;
                return (
                  <tr key={s.id} className="table-row">
                    <td>
                      <div className="flex items-center gap-2.5">
                        <Avatar name={s.name} color={s.color} size={30} />
                        <div><div className="font-semibold">{s.name}</div><div className="text-[11px] text-[var(--text-muted)]">{s.roll}</div></div>
                      </div>
                    </td>
                    <td className="text-[var(--text-muted)]">{s.className}</td>
                    <td className="tabular-nums">{s.factors.attendancePct}%</td>
                    <td className="font-bold tabular-nums">{p?.predictedPct ?? "—"}%</td>
                    <td>{risk && <Pill tone={risk.tone}>{risk.label}</Pill>}</td>
                    <td><Pill tone={p?.dataStatus === "verified" ? "success" : "warning"}>{p?.dataStatus === "verified" ? "Verified" : "Unverified"}</Pill></td>
                    <td><button className="btn btn-secondary btn-sm" onClick={() => setView(s)}><Eye size={13} /> View</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal open={!!view} onClose={() => setView(null)} title={view ? view.name : ""} wide>
        {view && (() => {
          const p = latestPredictionFor(view.id);
          const rm = publishedForStudent(roadmaps, view.id);
          return (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Avatar name={view.name} color={view.color} size={44} />
                <div>
                  <div className="text-[13px] text-[var(--text-muted)]">{view.roll} · {view.className} · Sem {view.semester}</div>
                  <div className="flex gap-1.5 mt-1.5">
                    {p && <Pill tone={p.dataStatus === "verified" ? "success" : "warning"}>{p.dataStatus === "verified" ? "Verified data" : "Unverified data"}</Pill>}
                    {p && <Pill tone={riskCategory(p.predictedPct).tone}>{riskCategory(p.predictedPct).label} · {p.predictedPct}%</Pill>}
                    <Pill tone={rm ? "success" : "muted"}>{rm ? "Roadmap published" : "No roadmap yet"}</Pill>
                  </div>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3">
                {FACTOR_KEYS.map((k) => (
                  <div key={k}>
                    <div className="flex justify-between text-[12px] mb-1"><span className="font-medium text-[var(--text-muted)]">{FACTOR_LABELS[k]}</span><span className="font-bold tabular-nums">{view.factors[k]}%</span></div>
                    <ProgressBar value={view.factors[k]} tone={view.factors[k] < 60 ? "warning" : "accent"} />
                  </div>
                ))}
              </div>
              {rm && (
                <div className="rounded-xl bg-[#f7f8fa] border border-[var(--border)] p-4 text-[12.5px]">
                  <span className="font-semibold">{rm.subject}</span> roadmap · {rm.durationDays} days · focus on {rm.priorityFocus} · source: {rm.source === "ai_generated" ? "AI Gateway draft" : "manual"}
                </div>
              )}
            </div>
          );
        })()}
      </Modal>
    </div>
  );
}

export function TeacherSubjects() {
  const role = useAuth((s) => s.role);
  const perm = permissions(role);
  const scopedSubjects = SUBJECTS.filter(perm.scopeSubject);
  return (
    <div>
      <SectionHead title={role === "class_teacher" ? "Subjects" : "My Subjects"} desc={role === "class_teacher" ? "All subjects taught to CSE-3A." : "Subjects assigned to you."} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {scopedSubjects.map((sub) => {
          const takers = students.filter((s) => s.subjects.some((x) => x.name === sub));
          const avg = takers.length ? Math.round(takers.reduce((a, s) => a + (s.subjects.find((x) => x.name === sub)?.pct ?? 0), 0) / takers.length) : 0;
          return (
            <Card key={sub} hover className="p-5">
              <span className="w-10 h-10 rounded-xl bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center"><BookOpen size={17} /></span>
              <h3 className="font-display text-[15px] font-semibold mt-3">{sub}</h3>
              <p className="text-[12px] text-[var(--text-muted)] mt-0.5">{takers.length} tracked students</p>
              <div className="mt-3"><ProgressBar value={avg} tone={avg >= 75 ? "success" : avg >= 55 ? "warning" : "danger"} /></div>
              <div className="text-[12px] text-[var(--text-muted)] mt-1.5">Class average {avg}%</div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export function TeacherPerformance() {
  const role = useAuth((s) => s.role);
  const perm = permissions(role);
  const scoped = students.filter(perm.scopeStudents);
  const avgFactors = FACTOR_KEYS.map((k) => ({
    label: FACTOR_LABELS[k],
    value: Math.round(scoped.reduce((a, s) => a + s.factors[k], 0) / scoped.length),
  }));
  const bands = [
    { label: "On track", color: "#16A34A", count: scoped.filter((s) => riskCategory(latestPredictionFor(s.id)?.predictedPct ?? 0).tone === "success").length },
    { label: "Attention", color: "#D97706", count: scoped.filter((s) => riskCategory(latestPredictionFor(s.id)?.predictedPct ?? 0).tone === "warning").length },
    { label: "At risk", color: "#DC2626", count: scoped.filter((s) => riskCategory(latestPredictionFor(s.id)?.predictedPct ?? 0).tone === "danger").length },
  ];
  return (
    <div>
      <SectionHead title="Performance" desc={`Aggregate signals across ${scoped.length} students in your scope.`} right={<Pill tone="accent"><TrendingUp size={11} /> {scoped.length} students · <Users size={11} /> {perm.label}</Pill>} />
      <div className="grid lg:grid-cols-2 gap-5">
        <FactorBarCard data={avgFactors} title="Class factor averages" sub="Where the cohort is strongest and weakest" />
        <DistributionChart data={bands} />
      </div>
    </div>
  );
}


