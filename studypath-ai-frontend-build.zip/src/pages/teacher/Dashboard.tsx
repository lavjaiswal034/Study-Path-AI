import { AlertTriangle, ClipboardList, Route, Users } from "lucide-react";
import { useMemo, useRef } from "react";
import { DistributionChart } from "../../components/charts";
import { Avatar, Card, Pill, SectionHead, StatCard, TASK_STATUS } from "../../components/ui";
import { latestPredictionFor, students } from "../../data";
import { riskCategory } from "../../lib/ai";
import { useEnterStagger, useRowStagger } from "../../lib/hooks";
import { allTasks, permissions, useApp, useAuth } from "../../store";

export default function TeacherDashboard() {
  const role = useAuth((s) => s.role);
  const roadmaps = useApp((s) => s.roadmaps);
  const navigate = useApp((s) => s.navigate);
  const perm = permissions(role);
  const scopeRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const scoped = useMemo(() => students.filter(perm.scopeStudents), [perm]);
  const preds = scoped.map((s) => ({ s, p: latestPredictionFor(s.id) })).filter((x) => x.p);
  const avg = preds.length ? preds.reduce((a, x) => a + x.p.predictedPct, 0) / preds.length : 0;
  const atRisk = preds.filter((x) => x.p.predictedPct < 55);
  const queue = allTasks(roadmaps).filter(({ task, roadmap }) => task.status === "submitted" && perm.scopeSubject(task.subject) && perm.scopeStudents(students.find((s) => s.id === roadmap.studentId)!));
  const published = roadmaps.filter((r) => r.status === "published" && perm.scopeStudents(students.find((s) => s.id === r.studentId)!));

  const bands = [
    { label: "On track", color: "#16A34A", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "success").length },
    { label: "Attention", color: "#D97706", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "warning").length },
    { label: "At risk", color: "#DC2626", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "danger").length },
  ];

  useEnterStagger(scopeRef, ".stat-card, .dash-card");
  useRowStagger(listRef, []);

  return (
    <div ref={scopeRef}>
      <SectionHead title="Teacher dashboard" desc={`${perm.label} · live view of your scope`} right={<button className="btn btn-primary" onClick={() => navigate("roadmaps")}><Route size={15} /> Open roadmaps</button>} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <StatCard icon={Users} label="Students in scope" value={scoped.length} tone="accent" />
        <StatCard icon={AlertTriangle} label="Avg predicted score" value={Math.round(avg * 10) / 10} decimals={1} suffix="%" tone={avg < 55 ? "danger" : "success"} />
        <StatCard icon={ClipboardList} label="Awaiting verification" value={queue.length} tone="warning" />
        <StatCard icon={Route} label="Published roadmaps" value={published.length} tone="dark" />
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <Card className="dash-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-[15px] font-semibold">At-risk students</h3>
            <Pill tone="danger">{atRisk.length} flagged</Pill>
          </div>
          <div ref={listRef} className="space-y-2.5">
            {atRisk.length === 0 && <p className="text-[13px] text-[var(--text-muted)]">No students below the 55% threshold. Good shape.</p>}
            {atRisk.map(({ s, p }) => (
              <div key={s.id} className="table-row flex items-center gap-3 p-3 rounded-xl border border-[var(--border)]">
                <Avatar name={s.name} color={s.color} size={36} />
                <div className="flex-1 min-w-0">
                  <div className="text-[13.5px] font-semibold truncate">{s.name}</div>
                  <div className="text-[11.5px] text-[var(--text-muted)]">{s.className} · predicted {p.predictedPct}%</div>
                </div>
                <Pill tone="danger">{riskCategory(p.predictedPct).label}</Pill>
                <button className="btn btn-secondary btn-sm" onClick={() => navigate("roadmaps")}>Plan</button>
              </div>
            ))}
          </div>
        </Card>

        <div className="dash-card space-y-5">
          <DistributionChart data={bands} />
          <Card className="p-5">
            <h3 className="font-display text-[15px] font-semibold mb-3">Latest submissions</h3>
            <div className="space-y-2">
              {queue.slice(0, 3).map(({ task, roadmap }) => {
                const st = students.find((s) => s.id === roadmap.studentId)!;
                return (
                  <button key={task.id} onClick={() => navigate("verification")} className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-[#f7f8fa] transition-colors text-left">
                    <Avatar name={st.name} color={st.color} size={30} />
                    <span className="flex-1 min-w-0">
                      <span className="block text-[12.5px] font-semibold truncate">{task.title}</span>
                      <span className="block text-[11px] text-[var(--text-muted)]">{st.name} · {task.subject}</span>
                    </span>
                    <Pill tone={TASK_STATUS.submitted.tone}>{TASK_STATUS.submitted.label}</Pill>
                  </button>
                );
              })}
              {queue.length === 0 && <p className="text-[12.5px] text-[var(--text-muted)]">Nothing waiting for review.</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
