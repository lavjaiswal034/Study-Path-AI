import { ClipboardList, Eye, Plus, Route, Sparkles, Trash2, Users } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Card, EmptyState, Pill, SectionHead, TASK_STATUS, Tabs, cn } from "../../components/ui";
import { students } from "../../data";
import { useRowStagger } from "../../lib/hooks";
import { allTasks, permissions, useApp, useAuth } from "../../store";
import type { RoadmapDraft } from "../../types";
import { AIGenerate, ManualBuilder } from "./Builder";

export default function TeacherRoadmaps() {
  const role = useAuth((s) => s.role);
  const roadmaps = useApp((s) => s.roadmaps);
  const removeRoadmap = useApp((s) => s.removeRoadmap);
  const publishRoadmap = useApp((s) => s.publishRoadmap);
  const perm = permissions(role);

  const [tab, setTab] = useState("mine");
  const [editing, setEditing] = useState<RoadmapDraft | null>(null);
  const [creating, setCreating] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  const scoped = useMemo(
    () => roadmaps.filter((r) => perm.scopeSubject(r.subject) && perm.scopeStudents(students.find((s) => s.id === r.studentId)!)),
    [roadmaps, perm],
  );
  const rows = useMemo(() => allTasks(roadmaps).filter(({ task, roadmap }) => perm.scopeSubject(task.subject) && perm.scopeStudents(students.find((s) => s.id === roadmap.studentId)!)), [roadmaps, perm]);
  const [taskFilter, setTaskFilter] = useState("all");
  useRowStagger(listRef, [tab, taskFilter]);

  if (creating) return <ManualBuilder initial={editing ?? undefined} onDone={() => { setCreating(false); setEditing(null); }} />;
  if (tab === "ai") return <AIGenerate onDone={() => setTab("mine")} onEdit={(d) => { setEditing(d); setCreating(true); }} />;

  const progressRows = scoped.filter((r) => r.status === "published").map((r) => {
    const tasks = r.days.flatMap((d) => d.tasks);
    const done = tasks.filter((t) => t.status === "verified").length;
    return { r, tasks: tasks.length, done, pct: tasks.length ? Math.round((done / tasks.length) * 100) : 0 };
  });

  return (
    <div>
      <SectionHead
        title="Roadmaps"
        desc="Build plans manually or let the AI Gateway draft them — every draft needs your approval before students see it."
        right={<>
          <button className="btn btn-secondary" onClick={() => setTab("ai")}><Sparkles size={15} /> Generate with AI</button>
          <button className="btn btn-primary" onClick={() => { setEditing(null); setCreating(true); }}><Plus size={15} /> Create roadmap</button>
        </>}
      />

      <Tabs
        items={[
          { key: "mine", label: "My Roadmaps", count: scoped.length },
          { key: "tasks", label: "Task Management", count: rows.length },
          { key: "progress", label: "Student Progress", count: progressRows.length },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "mine" && (
        <div ref={listRef} className="space-y-3">
          {scoped.length === 0 && <EmptyState icon={Route} title="No roadmaps yet" desc="Create one manually or generate a draft with the AI Gateway." action={<button className="btn btn-primary" onClick={() => setCreating(true)}><Plus size={14} /> Create roadmap</button>} />}
          {scoped.map((r) => {
            const st = students.find((s) => s.id === r.studentId)!;
            const tasks = r.days.flatMap((d) => d.tasks).length;
            return (
              <Card key={r.id} hover className="table-row p-4">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="w-10 h-10 rounded-xl bg-[#f0f2f6] text-[var(--text-muted)] grid place-items-center"><Route size={17} /></span>
                  <div className="flex-1 min-w-[200px]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-[14px]">{st.name} · {r.subject}</span>
                      <Pill tone={r.status === "published" ? "success" : "warning"}>{r.status === "published" ? "Published" : "Draft"}</Pill>
                      <Pill tone={r.source === "ai_generated" ? "accent" : "muted"}>{r.source === "ai_generated" ? "AI Gateway" : "Manual"}</Pill>
                    </div>
                    <div className="text-[12px] text-[var(--text-muted)] mt-1">{r.durationDays} days · {tasks} tasks · focus: {r.priorityFocus}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {r.status === "draft" && <button className="btn btn-accent btn-sm" onClick={() => publishRoadmap(r.id)}>Publish</button>}
                    <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(r); setCreating(true); }}><Eye size={13} /> {r.status === "draft" ? "Edit" : "View"}</button>
                    <button className="btn btn-ghost btn-icon text-[var(--danger)]" onClick={() => removeRoadmap(r.id)} aria-label="Delete roadmap"><Trash2 size={15} /></button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {tab === "tasks" && (
        <div>
          <div className="flex gap-1.5 flex-wrap mb-4">
            {(["all", "not_started", "submitted", "verified", "needs_revision"] as const).map((f) => (
              <button key={f} onClick={() => setTaskFilter(f)} className={cn("px-3 py-1.5 rounded-full text-[12px] font-semibold border", taskFilter === f ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-white border-[var(--border)] text-[var(--text-muted)]")}>
                {f === "all" ? "All" : TASK_STATUS[f].label}
              </button>
            ))}
          </div>
          <Card className="p-0 overflow-hidden">
            <div ref={listRef} className="overflow-x-auto scroll-thin">
              <table className="table">
                <thead><tr><th>Task</th><th>Student</th><th>Day</th><th>Est.</th><th>Status</th></tr></thead>
                <tbody>
                  {rows.filter((x) => taskFilter === "all" || x.task.status === taskFilter).map(({ task, day, roadmap }) => {
                    const st = students.find((s) => s.id === roadmap.studentId)!;
                    return (
                      <tr key={task.id} className="table-row">
                        <td><div className="font-semibold">{task.title}</div><div className="text-[11px] text-[var(--text-muted)]">{task.subject}</div></td>
                        <td>{st.name}</td>
                        <td className="text-[var(--text-muted)]">Day {day.dayNumber}</td>
                        <td className="tabular-nums">{task.estimatedMinutes}m</td>
                        <td><Pill tone={TASK_STATUS[task.status].tone}>{TASK_STATUS[task.status].label}</Pill></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {tab === "progress" && (
        <div ref={listRef} className="space-y-3">
          {progressRows.length === 0 && <EmptyState icon={Users} title="No published roadmaps" desc="Student progress appears once a roadmap is published." />}
          {progressRows.map(({ r, done, tasks, pct }) => {
            const st = students.find((s) => s.id === r.studentId)!;
            return (
              <Card key={r.id} hover className="table-row p-4">
                <div className="flex items-center gap-4">
                  <div className="flex-1 min-w-[180px]">
                    <div className="font-semibold text-[13.5px]">{st.name} <span className="text-[var(--text-muted)] font-normal">· {r.subject}</span></div>
                    <div className="text-[11.5px] text-[var(--text-muted)] mt-0.5">{done}/{tasks} tasks verified</div>
                  </div>
                  <div className="w-48">
                    <div className="h-2 rounded-full bg-[#eef0f4] overflow-hidden">
                      <div className="h-full bg-[var(--success)] rounded-full transition-[width] duration-700" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  <span className="font-display font-bold text-[15px] w-12 text-right tabular-nums">{pct}%</span>
                  <ClipboardList size={16} className="text-[var(--text-muted)]" />
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
