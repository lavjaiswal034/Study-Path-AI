import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowLeft, ArrowUp, Bot, CalendarDays, Check, Clock, Pencil, Plus, RefreshCw, Sparkles, Trash2, Wand2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Card, Field, Modal, Pill, TYPE_META, cn } from "../../components/ui";
import { SUBJECTS, latestPredictionFor, students } from "../../data";
import { weakAreas } from "../../lib/ai";
import { generateRoadmapDraft, toRoadmapDraft, type GeneratedDay } from "../../lib/ai";
import { usePathDraw } from "../../lib/hooks";
import { permissions, useApp, useAuth } from "../../store";
import type { RoadmapDraft, RoadmapTask, TaskPriority, TaskType } from "../../types";

/* ================================================================== */
/* Manual builder                                                      */
/* ================================================================== */
const blankTask = (subject: string, studentId: string): RoadmapTask => ({
  id: `t_${Math.random().toString(36).slice(2, 8)}`,
  title: "", subject, type: "study", priority: "medium", estimatedMinutes: 30,
  assignTo: { scope: "student", ids: [studentId] }, status: "not_started",
});

export function ManualBuilder({ initial, onDone }: { initial?: RoadmapDraft; onDone: () => void }) {
  const role = useAuth((s) => s.role);
  const saveRoadmap = useApp((s) => s.saveRoadmap);
  const publishRoadmap = useApp((s) => s.publishRoadmap);
  const perm = permissions(role);

  const [studentId, setStudentId] = useState(initial?.studentId ?? students[0].id);
  const [subject, setSubject] = useState(initial?.subject ?? (perm.scopeSubject("Data Structures") ? "Data Structures" : SUBJECTS[0]));
  const [focus, setFocus] = useState(initial?.priorityFocus ?? "");
  const [days, setDays] = useState<RoadmapDraft["days"]>(
    initial?.days ?? [1, 2, 3].map((n) => ({ id: `d_${n}_${Math.random().toString(36).slice(2, 6)}`, dayNumber: n, title: `Day ${n}`, tasks: [] })),
  );
  const [editing, setEditing] = useState<{ dayId: string; task: RoadmapTask } | null>(null);
  const [draftId] = useState(initial?.id ?? `rm_${Date.now()}`);

  const scopedSubjects = SUBJECTS.filter(perm.scopeSubject);
  const addDay = () => setDays((d) => [...d, { id: `d_${Date.now()}`, dayNumber: d.length + 1, title: `Day ${d.length + 1}`, tasks: [] }]);
  const removeDay = (id: string) => setDays((d) => d.filter((x) => x.id !== id).map((x, i) => ({ ...x, dayNumber: i + 1 })));
  const move = (dayId: string, taskId: string, dir: -1 | 1) =>
    setDays((d) => d.map((day) => {
      if (day.id !== dayId) return day;
      const i = day.tasks.findIndex((t) => t.id === taskId);
      const j = i + dir;
      if (j < 0 || j >= day.tasks.length) return day;
      const tasks = [...day.tasks]; [tasks[i], tasks[j]] = [tasks[j], tasks[i]];
      return { ...day, tasks };
    }));

  const save = (publish: boolean) => {
    const draft: RoadmapDraft = {
      id: draftId, studentId, subject, predictionId: latestPredictionFor(studentId)?.id ?? "p_1",
      priorityFocus: focus || "Balanced revision", durationDays: days.length, days,
      status: publish ? "published" : "draft", source: initial?.source ?? "manual", createdAt: initial?.createdAt ?? new Date().toISOString(),
    };
    saveRoadmap(draft);
    if (publish) publishRoadmap(draftId);
    onDone();
  };

  return (
    <div>
      <button className="btn btn-ghost btn-sm mb-4" onClick={onDone}><ArrowLeft size={14} /> Back to roadmaps</button>
      <Card className="p-5 mb-5">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Field label="Student">
            <select className="select" value={studentId} onChange={(e) => setStudentId(e.target.value)}>
              {students.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.className}</option>)}
            </select>
          </Field>
          <Field label="Subject">
            <select className="select" value={subject} onChange={(e) => setSubject(e.target.value)} disabled={scopedSubjects.length === 1}>
              {scopedSubjects.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Priority focus" hint="What should the plan attack first?">
            <input className="input" value={focus} onChange={(e) => setFocus(e.target.value)} placeholder="e.g. Quiz Average · Trees" />
          </Field>
          <Field label="Duration">
            <div className="input flex items-center gap-2 bg-[#f7f8fa]"><CalendarDays size={15} className="text-[var(--text-muted)]" /> {days.length} days</div>
          </Field>
        </div>
      </Card>

      <div className="space-y-4">
        {days.map((day) => (
          <Card key={day.id} className="p-4">
            <div className="flex items-center justify-between mb-3">
              <input
                className="font-display text-[15px] font-semibold bg-transparent border-none outline-none focus:bg-[#f7f8fa] rounded px-1 -mx-1"
                value={day.title}
                onChange={(e) => setDays((d) => d.map((x) => (x.id === day.id ? { ...x, title: e.target.value } : x)))}
                aria-label={`Day ${day.dayNumber} title`}
              />
              <div className="flex items-center gap-1.5">
                <button className="btn btn-ghost btn-icon" onClick={addDay} aria-label="Add day"><Plus size={15} /></button>
                {days.length > 1 && <button className="btn btn-ghost btn-icon text-[var(--danger)]" onClick={() => removeDay(day.id)} aria-label="Remove day"><Trash2 size={15} /></button>}
              </div>
            </div>
            <div className="space-y-2">
              {day.tasks.map((t, i) => {
                const M = TYPE_META[t.type];
                return (
                  <div key={t.id} className="flex items-center gap-2.5 p-2.5 rounded-lg border border-[var(--border)] bg-[#FBFCFD]">
                    <span className="w-8 h-8 rounded-lg bg-[#f0f2f6] grid place-items-center text-[var(--text-muted)]"><M.icon size={14} /></span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] font-semibold truncate">{t.title || "Untitled task"}</div>
                      <div className="text-[11px] text-[var(--text-muted)]">{M.label} · {t.priority} · {t.estimatedMinutes} min</div>
                    </div>
                    <div className="flex items-center gap-0.5">
                      <button className="btn btn-ghost btn-icon" disabled={i === 0} onClick={() => move(day.id, t.id, -1)} aria-label="Move up"><ArrowUp size={14} /></button>
                      <button className="btn btn-ghost btn-icon" disabled={i === day.tasks.length - 1} onClick={() => move(day.id, t.id, 1)} aria-label="Move down"><ArrowDown size={14} /></button>
                      <button className="btn btn-ghost btn-icon" onClick={() => setEditing({ dayId: day.id, task: t })} aria-label="Edit task"><Pencil size={14} /></button>
                      <button className="btn btn-ghost btn-icon text-[var(--danger)]" onClick={() => setDays((d) => d.map((x) => (x.id === day.id ? { ...x, tasks: x.tasks.filter((y) => y.id !== t.id) } : x)))} aria-label="Delete task"><Trash2 size={14} /></button>
                    </div>
                  </div>
                );
              })}
              <button className="btn btn-secondary btn-sm w-full" onClick={() => setEditing({ dayId: day.id, task: blankTask(subject, studentId) })}>
                <Plus size={13} /> Add task
              </button>
            </div>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-2 mt-5">
        <button className="btn btn-secondary" onClick={() => save(false)}>Save draft</button>
        <button className="btn btn-primary" onClick={() => save(true)}><Check size={15} /> Publish roadmap</button>
        <span className="text-[11.5px] text-[var(--text-muted)] ml-2">Publishing is always an explicit teacher action — never automatic.</span>
      </div>

      <TaskFormModal
        open={!!editing}
        initial={editing?.task}
        subject={subject}
        onClose={() => setEditing(null)}
        onSave={(task) => {
          if (!editing) return;
          setDays((d) => d.map((x) => {
            if (x.id !== editing.dayId) return x;
            const exists = x.tasks.some((t) => t.id === task.id);
            return { ...x, tasks: exists ? x.tasks.map((t) => (t.id === task.id ? task : t)) : [...x.tasks, task] };
          }));
          setEditing(null);
        }}
      />
    </div>
  );
}

function TaskFormModal({ open, initial, subject, onClose, onSave }: { open: boolean; initial?: RoadmapTask; subject: string; onClose: () => void; onSave: (t: RoadmapTask) => void }) {
  const [t, setT] = useState<RoadmapTask>(initial ?? blankTask(subject, students[0].id));
  useEffect(() => { if (initial) setT(initial); else setT(blankTask(subject, students[0].id)); }, [initial, open, subject]);
  const set = <K extends keyof RoadmapTask>(k: K, v: RoadmapTask[K]) => setT((p) => ({ ...p, [k]: v }));
  return (
    <Modal open={open} onClose={onClose} title={initial?.title ? "Edit task" : "New task"} wide
      footer={<>
        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" disabled={!t.title.trim()} onClick={() => onSave({ ...t, title: t.title.trim(), subject })}>Save task</button>
      </>}>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2"><Field label="Title"><input className="input" value={t.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Graph traversal lab" /></Field></div>
        <div className="sm:col-span-2"><Field label="Description"><textarea className="textarea" rows={2} value={t.description ?? ""} onChange={(e) => set("description", e.target.value)} placeholder="Optional guidance for the student" /></Field></div>
        <Field label="Type">
          <select className="select" value={t.type} onChange={(e) => set("type", e.target.value as TaskType)}>
            {(Object.keys(TYPE_META) as TaskType[]).map((k) => <option key={k} value={k}>{TYPE_META[k].label}</option>)}
          </select>
        </Field>
        <Field label="Priority">
          <select className="select" value={t.priority} onChange={(e) => set("priority", e.target.value as TaskPriority)}>
            <option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option>
          </select>
        </Field>
        <Field label="Estimated minutes"><input type="number" min={5} className="input" value={t.estimatedMinutes} onChange={(e) => set("estimatedMinutes", Number(e.target.value) || 0)} /></Field>
        <Field label="Due date"><input type="date" className="input" value={t.dueDate ?? ""} onChange={(e) => set("dueDate", e.target.value || undefined)} /></Field>
        <div className="sm:col-span-2"><Field label="Resources (comma separated)" hint="Links or references the student should use"><input className="input" value={(t.resources ?? []).join(", ")} onChange={(e) => set("resources", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} /></Field></div>
        <Field label="Assign to">
          <select className="select" value={t.assignTo.scope} onChange={(e) => set("assignTo", { scope: e.target.value as RoadmapTask["assignTo"]["scope"], ids: t.assignTo.ids })}>
            <option value="student">This student</option><option value="selected">Selected students</option><option value="class">Whole class</option>
          </select>
        </Field>
      </div>
    </Modal>
  );
}

/* ================================================================== */
/* AI Gateway generation                                               */
/* ================================================================== */
const STATUS_LINES = ["Reading performance data…", "Identifying weak areas…", "Drafting daily tasks…"];

export function AIGenerate({ onDone, onEdit }: { onDone: () => void; onEdit: (draft: RoadmapDraft) => void }) {
  const role = useAuth((s) => s.role);
  const apiKey = useApp((s) => s.apiKey);
  const setApiKey = useApp((s) => s.setApiKey);
  const saveRoadmap = useApp((s) => s.saveRoadmap);
  const perm = permissions(role);

  const [studentId, setStudentId] = useState(students[0].id);
  const [subject, setSubject] = useState(perm.scopeSubject("Data Structures") ? "Data Structures" : SUBJECTS[0]);
  const [daysCount, setDaysCount] = useState(7);
  const [minutes, setMinutes] = useState(90);
  const [phase, setPhase] = useState<"form" | "generating" | "preview">("form");
  const [line, setLine] = useState(0);
  const [result, setResult] = useState<{ priorityFocus: string; days: GeneratedDay[]; fellBack: boolean } | null>(null);
  const [draft, setDraft] = useState<RoadmapDraft | null>(null);
  const pathRef = useRef<SVGPathElement>(null);

  const prediction = latestPredictionFor(studentId);
  const weak = prediction ? weakAreas(prediction.factors) : [];
  const scopedSubjects = SUBJECTS.filter(perm.scopeSubject);

  usePathDraw(pathRef, phase === "preview");

  useEffect(() => {
    if (phase !== "generating") return;
    setLine(0);
    const t1 = setTimeout(() => setLine(1), 700);
    const t2 = setTimeout(() => setLine(2), 1400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [phase]);

  const run = async () => {
    setPhase("generating");
    const res = await generateRoadmapDraft({
      studentName: students.find((s) => s.id === studentId)!.name,
      subject, days: daysCount, minutesPerDay: minutes, weak, apiKey,
    });
    setResult(res);
    const d = toRoadmapDraft(res, { id: `rm_ai_${Date.now()}`, studentId, subject, predictionId: prediction?.id ?? "p_1", source: "ai_generated" });
    setDraft(d);
    setPhase("preview");
  };

  const accept = () => { if (draft) { saveRoadmap(draft); onDone(); } };

  const nodeContainer = { hidden: {}, show: { transition: { staggerChildren: 0.1, delayChildren: 0.3 } } };
  const nodeItem = { hidden: { opacity: 0, scale: 0.4, y: 16 }, show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 18 } } };

  return (
    <div>
      <button className="btn btn-ghost btn-sm mb-4" onClick={onDone}><ArrowLeft size={14} /> Back to roadmaps</button>

      <AnimatePresence mode="wait">
        {phase === "form" && (
          <motion.div key="form" initial={{ opacity: 1 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
            <Card className="p-5 max-w-2xl">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-9 h-9 rounded-[10px] bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center"><Wand2 size={16} /></span>
                <h3 className="font-display text-[16px] font-semibold">Generate with AI Gateway</h3>
              </div>
              <p className="text-[12.5px] text-[var(--text-muted)] mb-5">The Gateway reads the student's latest ML prediction and drafts a plan. You always review before anything is published.</p>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Student">
                  <select className="select" value={studentId} onChange={(e) => setStudentId(e.target.value)}>
                    {students.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.className}</option>)}
                  </select>
                </Field>
                <Field label="Subject">
                  <select className="select" value={subject} onChange={(e) => setSubject(e.target.value)} disabled={scopedSubjects.length === 1}>
                    {scopedSubjects.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </Field>
                <Field label="Plan length (days)"><input type="number" min={3} max={14} className="input" value={daysCount} onChange={(e) => setDaysCount(Math.max(3, Math.min(14, Number(e.target.value) || 7)))} /></Field>
                <Field label="Available minutes / day"><input type="number" min={30} max={240} step={15} className="input" value={minutes} onChange={(e) => setMinutes(Number(e.target.value) || 90)} /></Field>
              </div>

              <div className="mt-4 rounded-xl bg-[#f7f8fa] border border-[var(--border)] p-3.5">
                <div className="text-[11.5px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Weak areas detected (from ML prediction)</div>
                <div className="flex flex-wrap gap-1.5">
                  {weak.map((w) => <Pill key={w.label} tone={w.value < 60 ? "danger" : "warning"}>{w.label} · {w.value}%</Pill>)}
                </div>
              </div>

              <Field label="AI Gateway key (optional)" hint="Held in memory only, never hardcoded. Leave blank to use the built-in drafting engine. Production builds must route this through a backend.">
                <input className="input" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-…" />
              </Field>

              <button className="btn btn-primary mt-5" onClick={run}><Sparkles size={15} /> Generate draft</button>
            </Card>
          </motion.div>
        )}

        {phase === "generating" && (
          <motion.div key="gen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="card p-10 max-w-2xl">
            <Bot size={26} className="text-[var(--accent)]" />
            <h3 className="font-display text-[17px] font-semibold mt-3">AI Gateway is drafting</h3>
            <div className="mt-4 space-y-2.5">
              {STATUS_LINES.map((s, i) => (
                <div key={s} className={cn("flex items-center gap-2.5 text-[13px] transition-colors", i <= line ? "text-[var(--text-primary)]" : "text-[#C2C7D0]")}>
                  <span className={cn("w-5 h-5 rounded-full grid place-items-center border", i < line ? "bg-[var(--success)] border-[var(--success)] text-white" : i === line ? "border-[var(--accent)] text-[var(--accent)]" : "border-[var(--border)]")}>
                    {i < line ? <Check size={11} strokeWidth={3} /> : <Clock size={11} className={i === line ? "animate-spin" : ""} />}
                  </span>
                  {s}
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {phase === "preview" && result && draft && (
          <motion.div key="preview" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            {result.fellBack && (
              <div className="mb-4 rounded-xl border border-[#F4DFB6] bg-[var(--warning-soft)] px-4 py-3 text-[12.5px] text-[#92400E]">
                The external gateway didn't return a usable response, so the built-in drafting engine produced this draft instead.
              </div>
            )}
            <div className="grid lg:grid-cols-[300px_1fr] gap-5 items-start">
              <Card className="p-5">
                <div className="text-[11.5px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Draft path</div>
                <svg viewBox="0 0 60 420" className="w-10 mx-auto" aria-hidden="true">
                  <path ref={pathRef} d="M 30 10 C 6 80, 54 150, 30 210 C 6 280, 54 350, 30 410" fill="none" stroke="var(--accent)" strokeWidth={5} strokeLinecap="round" />
                </svg>
                <div className="mt-3 text-center">
                  <div className="font-display text-[20px] font-bold">{draft.durationDays} days</div>
                  <div className="text-[11.5px] text-[var(--text-muted)]">≈ {draft.days.reduce((a, d) => a + d.tasks.reduce((x, t) => x + t.estimatedMinutes, 0), 0)} min total</div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-display text-[16px] font-semibold">Generated draft — {students.find((s) => s.id === studentId)?.name}</h3>
                    <p className="text-[12px] text-[var(--text-muted)] mt-0.5">Focus: {result.priorityFocus} · AI Gateway output is always a draft</p>
                  </div>
                  <Pill tone="warning">Draft</Pill>
                </div>
                <motion.div variants={nodeContainer} initial="hidden" animate="show" className="space-y-2.5">
                  {draft.days.map((day) => (
                    <motion.div key={day.id} variants={nodeItem} className="rounded-xl border border-[var(--border)] p-3.5">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-full bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center text-[12px] font-bold shrink-0">{day.dayNumber}</span>
                        <span className="font-semibold text-[13.5px]">{day.title}</span>
                        <span className="ml-auto text-[11px] text-[var(--text-muted)]">{day.tasks.reduce((a, t) => a + t.estimatedMinutes, 0)} min</span>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {day.tasks.map((t) => {
                          const M = TYPE_META[t.type];
                          return <Pill key={t.id} tone="muted"><M.icon size={10} /> {t.title}</Pill>;
                        })}
                      </div>
                    </motion.div>
                  ))}
                </motion.div>

                <div className="flex flex-wrap gap-2 mt-5">
                  <button className="btn btn-primary" onClick={accept}><Check size={15} /> Accept as draft</button>
                  <button className="btn btn-secondary" onClick={() => onEdit(draft)}><Pencil size={14} /> Edit manually</button>
                  <button className="btn btn-secondary" onClick={run}><RefreshCw size={14} /> Regenerate</button>
                  <button className="btn btn-danger" onClick={() => { setResult(null); setDraft(null); setPhase("form"); }}><Trash2 size={14} /> Discard</button>
                </div>
              </Card>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
