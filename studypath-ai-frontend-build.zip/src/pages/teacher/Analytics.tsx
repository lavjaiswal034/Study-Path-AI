import { Download, FileText } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { ActivityChart, DistributionChart, FactorBarCard } from "../../components/charts";
import { Avatar, Card, Pill, SectionHead } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, SUBJECTS, latestPredictionFor, students } from "../../data";
import { riskCategory } from "../../lib/ai";
import { useRowStagger } from "../../lib/hooks";
import { permissions, useApp, useAuth } from "../../store";

export function TeacherPredictions() {
  const role = useAuth((s) => s.role);
  const perm = permissions(role);
  const scoped = students.filter(perm.scopeStudents);
  const ref = useRef<HTMLDivElement>(null);
  useRowStagger(ref, []);
  return (
    <div>
      <SectionHead title="Predictions" desc="Latest E46_V1 output per student in your scope. Numbers are model output — never AI prose." />
      <Card className="p-0 overflow-hidden">
        <div ref={ref} className="overflow-x-auto scroll-thin">
          <table className="table">
            <thead><tr><th>Student</th><th>Predicted</th><th>Marks</th><th>Features</th><th>Data</th><th>Risk</th><th>Run date</th></tr></thead>
            <tbody>
              {scoped.map((s) => {
                const p = latestPredictionFor(s.id);
                if (!p) return null;
                const risk = riskCategory(p.predictedPct);
                return (
                  <tr key={s.id} className="table-row">
                    <td><div className="flex items-center gap-2.5"><Avatar name={s.name} color={s.color} size={28} /><span className="font-semibold">{s.name}</span></div></td>
                    <td className="font-bold tabular-nums">{p.predictedPct}%</td>
                    <td className="tabular-nums text-[var(--text-muted)]">{p.predictedMarks}/{p.maxMarks}</td>
                    <td>{p.featureSetVersion}</td>
                    <td><Pill tone={p.dataStatus === "verified" ? "success" : "warning"}>{p.dataStatus === "verified" ? "Verified" : "Unverified"}</Pill></td>
                    <td><Pill tone={risk.tone}>{risk.label}</Pill></td>
                    <td className="text-[var(--text-muted)]">{new Date(p.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function downloadCSV(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

export function TeacherAnalytics() {
  const role = useAuth((s) => s.role);
  const perm = permissions(role);
  const [subject, setSubject] = useState(SUBJECTS.filter(perm.scopeSubject)[0]);
  const scoped = useMemo(() => students.filter(perm.scopeStudents), [perm]);

  const preds = scoped.map((s) => ({ s, p: latestPredictionFor(s.id)! })).filter((x) => x.p);
  const avgFactors = FACTOR_KEYS.map((k) => ({ label: FACTOR_LABELS[k], value: Math.round(scoped.reduce((a, s) => a + s.factors[k], 0) / scoped.length) }));
  const bands = [
    { label: "On track", color: "#16A34A", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "success").length },
    { label: "Attention", color: "#D97706", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "warning").length },
    { label: "At risk", color: "#DC2626", count: preds.filter((x) => riskCategory(x.p.predictedPct).tone === "danger").length },
  ];

  return (
    <div>
      <SectionHead title="Analytics" desc="Filter by subject to slice your scope." right={
        <select className="select w-auto" value={subject} onChange={(e) => setSubject(e.target.value)} aria-label="Filter by subject">
          {SUBJECTS.filter(perm.scopeSubject).map((s) => <option key={s}>{s}</option>)}
        </select>
      } />
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        <DistributionChart data={bands} />
        <FactorBarCard data={avgFactors} title={`Factor averages — ${subject}`} sub="Cohort-level academic signals" />
      </div>
      <ActivityChart data={[
        { label: "Mon", verified: 4, submitted: 1 }, { label: "Tue", verified: 3, submitted: 2 },
        { label: "Wed", verified: 2, submitted: 3 }, { label: "Thu", verified: 5, submitted: 1 },
        { label: "Fri", verified: 3, submitted: 2 }, { label: "Sat", verified: 1, submitted: 0 }, { label: "Sun", verified: 2, submitted: 1 },
      ]} />
    </div>
  );
}

export function TeacherReports() {
  const role = useAuth((s) => s.role);
  const roadmaps = useApp((s) => s.roadmaps);
  const perm = permissions(role);
  const scoped = students.filter(perm.scopeStudents);

  const exportPredictions = () =>
    downloadCSV("studypath-predictions.csv", [
      ["Student", "Roll", "Class", "Predicted %", "Marks", "Data status", "Risk"],
      ...scoped.map((s) => {
        const p = latestPredictionFor(s.id);
        return [s.name, s.roll, s.className, p?.predictedPct ?? "", p?.predictedMarks ?? "", p?.dataStatus ?? "", p ? riskCategory(p.predictedPct).label : ""];
      }),
    ]);

  const exportRoadmaps = () =>
    downloadCSV("studypath-roadmaps.csv", [
      ["Student", "Subject", "Days", "Tasks", "Status", "Source"],
      ...roadmaps.map((r) => [students.find((s) => s.id === r.studentId)?.name ?? "", r.subject, r.durationDays, r.days.flatMap((d) => d.tasks).length, r.status, r.source]),
    ]);

  return (
    <div>
      <SectionHead title="Reports" desc="Export scoped snapshots as CSV." />
      <div className="grid sm:grid-cols-2 gap-4 max-w-3xl">
        <Card className="p-5" hover>
          <span className="w-10 h-10 rounded-xl bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center"><FileText size={17} /></span>
          <h3 className="font-display text-[15px] font-semibold mt-3">Prediction snapshot</h3>
          <p className="text-[12.5px] text-[var(--text-muted)] mt-1">Latest E46_V1 prediction per student with risk band and data status.</p>
          <button className="btn btn-secondary btn-sm mt-4" onClick={exportPredictions}><Download size={13} /> Export CSV</button>
        </Card>
        <Card className="p-5" hover>
          <span className="w-10 h-10 rounded-xl bg-[var(--success-soft)] text-[var(--success)] grid place-items-center"><FileText size={17} /></span>
          <h3 className="font-display text-[15px] font-semibold mt-3">Roadmap register</h3>
          <p className="text-[12.5px] text-[var(--text-muted)] mt-1">All roadmaps in scope with status, source and task counts.</p>
          <button className="btn btn-secondary btn-sm mt-4" onClick={exportRoadmaps}><Download size={13} /> Export CSV</button>
        </Card>
      </div>
      <p className="text-[11.5px] text-[var(--text-muted)] mt-4 flex items-center gap-1.5"><Pill tone="muted">Scope</Pill> {perm.label}</p>
    </div>
  );
}
