import { motion } from "framer-motion";
import { ArrowRight, Brain, GraduationCap, Route, ShieldCheck, Sparkles, UserCog, Users } from "lucide-react";
import { useEffect, useRef } from "react";
import { useReducedMotion } from "../lib/hooks";
import { useApp, useAuth } from "../store";
import type { Role } from "../types";

const ROLES: { role: Role; icon: typeof Users; title: string; desc: string; tint: string }[] = [
  { role: "student", icon: GraduationCap, title: "Student", desc: "See your prediction, follow your AI roadmap, submit tasks.", tint: "#2563EB" },
  { role: "class_teacher", icon: Users, title: "Class Teacher", desc: "Oversee the whole class — roadmaps, verification, analytics.", tint: "#16A34A" },
  { role: "subject_teacher", icon: ShieldCheck, title: "Subject Teacher", desc: "Build subject roadmaps and verify submissions you receive.", tint: "#D97706" },
  { role: "admin", icon: UserCog, title: "Admin", desc: "Manage users, classes, branches and prediction analytics.", tint: "#111318" },
];

function Constellation() {
  const ref = useRef<HTMLCanvasElement>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || reduced) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let w = 0, h = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const resize = () => {
      w = canvas.offsetWidth; h = canvas.offsetHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const N = 42;
    const pts = Array.from({ length: N }, () => ({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35,
    }));
    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
      }
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y;
          const dist = Math.hypot(dx, dy);
          if (dist < 110) {
            ctx.strokeStyle = `rgba(96,140,255,${(1 - dist / 110) * 0.22})`;
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke();
          }
        }
      }
      for (const p of pts) {
        ctx.fillStyle = "rgba(140,170,255,0.7)";
        ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, Math.PI * 2); ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [reduced]);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full" aria-hidden="true" />;
}

export default function Login() {
  const login = useAuth((s) => s.login);
  const navigate = useApp((s) => s.navigate);

  const enter = (role: Role) => {
    login(role);
    navigate("dashboard");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.05fr_1fr]">
      {/* left — identity */}
      <div className="relative overflow-hidden bg-[#0E1014] text-white flex flex-col justify-between p-8 sm:p-12">
        <Constellation />
        <div className="relative">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-[10px] bg-white/10 border border-white/15 grid place-items-center">
              <svg width="20" height="20" viewBox="0 0 32 32" fill="none" aria-hidden="true">
                <path d="M9 23c0-7 4-12 7-12s7 5 7 12" stroke="#5B8CFF" strokeWidth="2.6" strokeLinecap="round" />
                <circle cx="16" cy="10" r="2.6" fill="#fff" />
              </svg>
            </span>
            <span className="font-display text-[18px] font-semibold">StudyPath AI</span>
          </div>
        </div>

        <div className="relative max-w-lg">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-1.5 pill bg-white/10 text-[#9DB4FF] border border-white/10 mb-5">
              <Sparkles size={12} /> Academic intelligence platform
            </span>
            <h1 className="font-display text-[34px] sm:text-[44px] leading-[1.08] font-bold">
              Know the outcome.<br />Then change it.
            </h1>
            <p className="mt-4 text-[14.5px] leading-6 text-white/65">
              StudyPath reads academic signals through ML model <span className="text-white font-semibold">E46_V1</span> to predict
              performance — then an AI Gateway drafts a day-by-day roadmap your teachers approve and verify.
            </p>
          </motion.div>

          <div className="mt-8 grid grid-cols-3 gap-3">
            {[
              { icon: Brain, t: "Predict", s: "ML model E46_V1" },
              { icon: Route, t: "Plan", s: "AI Gateway drafts" },
              { icon: ShieldCheck, t: "Verify", s: "Teachers approve" },
            ].map((x, i) => (
              <motion.div
                key={x.t}
                initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 + i * 0.12 }}
                className="rounded-xl border border-white/10 bg-white/[0.04] p-3.5"
              >
                <x.icon size={17} className="text-[#7FA3FF]" />
                <div className="mt-2 text-[13px] font-semibold">{x.t}</div>
                <div className="text-[11px] text-white/50">{x.s}</div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="relative text-[11.5px] text-white/40">
          Prototype build · mock data layer · predictions are not confidence scores
        </div>
      </div>

      {/* right — role entry */}
      <div className="flex flex-col justify-center p-8 sm:p-12 bg-[var(--bg)]">
        <div className="mb-7">
          <h2 className="font-display text-[22px] font-semibold">Choose your workspace</h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Demo authentication — pick a role to explore its full workflow.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-3.5">
          {ROLES.map((r, i) => (
            <motion.button
              key={r.role}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.08, type: "spring", stiffness: 260, damping: 22 }}
              whileHover={{ y: -4 }}
              onClick={() => enter(r.role)}
              className="card card-hover p-5 text-left group"
            >
              <span className="w-10 h-10 rounded-[11px] grid place-items-center text-white" style={{ background: r.tint }}>
                <r.icon size={19} />
              </span>
              <div className="mt-3.5 font-display text-[15.5px] font-semibold flex items-center gap-2">
                {r.title}
                <ArrowRight size={15} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-[var(--accent)]" />
              </div>
              <p className="mt-1 text-[12.5px] leading-5 text-[var(--text-muted)]">{r.desc}</p>
            </motion.button>
          ))}
        </div>
        <p className="mt-6 text-[11.5px] text-[var(--text-muted)]">
          Structured as an AuthProvider interface — a real credential check can replace this screen without touching the rest of the app.
        </p>
      </div>
    </div>
  );
}
