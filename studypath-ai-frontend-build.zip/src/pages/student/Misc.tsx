import { Bell, BookOpen, CheckCheck, FileText, ListChecks, Lock, Mail, Newspaper, PlayCircle, RotateCcw, TrendingUp } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { ActivityChart, FactorBarCard } from "../../components/charts";
import { Avatar, Card, EmptyState, Modal, Pill, ProgressBar, SectionHead, StatCard, cn } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, demoStudent, notifications, predictions, resources } from "../../data";
import { useEnterStagger, useRowStagger } from "../../lib/hooks";
import { publishedForStudent, useApp, useAuth } from "../../store";
import type { LearningResource } from "../../types";

const KIND = {
  video: { icon: PlayCircle, label: "Video" },
  notes: { icon: FileText, label: "Notes" },
  article: { icon: Newspaper, label: "Article" },
  "problem-set": { icon: ListChecks, label: "Problem set" },
} as const;

function Subjects() {
  const ref = useRef<HTMLDivElement>(null);
  useEnterStagger(ref, ".subj");
  return (
    <div ref={ref}>
      <SectionHead title="My Subjects" desc="Current enrolment and standing per subject." />
      <div className="grid sm:grid-cols-2 gap-4">
        {demoStudent.subjects.map((s) => (
          <Card key={s.name} hover className="subj p-5">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-xl bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center"><BookOpen size={17} /></span>
              <Pill tone={s.pct >= 75 ? "success" : s.pct >= 55 ? "warning" : "danger"}>Grade {s.grade}</Pill>
            </div>
            <h3 className="font-display text-[16px] font-semibold mt-3">{s.name}</h3>
            <div className="mt-3"><ProgressBar value={s.pct} tone={s.pct >= 75 ? "success" : "accent"} /></div>
            <div className="text-[12px] text-[var(--text-muted)] mt-1.5">{s.pct}% internal standing</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Performance() {
  const history = predictions.filter((p) => p.studentId === demoStudent.id).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  return (
    <div>
      <SectionHead title="Performance" desc="Your academic signals over time — the same inputs the model reads." />
      <div className="grid lg:grid-cols-2 gap-5">
        <FactorBarCard data={FACTOR_KEYS.map((k) => ({ label: FACTOR_LABELS[k], value: demoStudent.factors[k] }))} title="Current factors" />
        <ActivityChart data={[
          { label: "Mon", verified: 2, submitted: 0 }, { label: "Tue", verified: 1, submitted: 1 },
          { label: "Wed", verified: 0, submitted: 2 }, { label: "Thu", verified: 2, submitted: 0 },
          { label: "Fri", verified: 1, submitted: 1 }, { label: "Sat", verified: 0, submitted: 0 }, { label: "Sun", verified: 1, submitted: 0 },
        ]} />
      </div>
      <div className="mt-5 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={TrendingUp} label="Prediction delta" value={72.4 - 61.5} decimals={1} suffix="%" sub="vs 70 days ago" tone="success" />
        <StatCard icon={CheckCheck} label="Tasks verified" value={3} tone="accent" />
        <StatCard icon={Bell} label="Revisions requested" value={1} tone="warning" />
        <StatCard icon={Mail} label="Attendance" value={84} suffix="%" tone="accent" />
      </div>
      <p className="text-[11.5px] text-[var(--text-muted)] mt-4">Trend: {history.length} prediction runs recorded.</p>
    </div>
  );
}

function Resources() {
  const [subject, setSubject] = useState("Data Structures");
  const [open, setOpen] = useState<LearningResource | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  const list = useMemo(() => resources.filter((r) => r.subject === subject), [subject]);
  useEnterStagger(ref, ".res", [subject]);

  return (
    <div ref={ref}>
      <SectionHead title="Learning Resources" desc="Curated material matched to your roadmap topics." />
      <div className="flex gap-1.5 flex-wrap mb-5">
        {["Data Structures", "DBMS"].map((s) => (
          <button key={s} onClick={() => setSubject(s)}
            className={cn("px-3 py-1.5 rounded-full text-[12.5px] font-semibold border transition-colors", subject === s ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-white border-[var(--border)] text-[var(--text-muted)]")}>
            {s}
          </button>
        ))}
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {list.map((r) => {
          const K = KIND[r.kind];
          return (
            <Card key={r.id} hover className="res p-5">
              <div className="flex items-start justify-between">
                <span className="w-10 h-10 rounded-xl bg-[#f0f2f6] text-[var(--text-muted)] grid place-items-center"><K.icon size={17} /></span>
                {r.locked ? <Pill tone="muted"><Lock size={10} /> Restricted</Pill> : <Pill tone="accent">{K.label}</Pill>}
              </div>
              <h3 className="font-display text-[14.5px] font-semibold mt-3">{r.title}</h3>
              <p className="text-[12.5px] text-[var(--text-muted)] mt-1 leading-5">{r.summary}</p>
              <div className="flex items-center justify-between mt-4">
                <span className="text-[11.5px] text-[var(--text-muted)]">{r.minutes} min</span>
                <button className="btn btn-secondary btn-sm" onClick={() => setOpen(r)}>{r.locked ? "Request access" : "Open"}</button>
              </div>
            </Card>
          );
        })}
      </div>

      <Modal open={!!open} onClose={() => setOpen(null)} title={open?.title ?? ""}
        footer={<button className="btn btn-primary" onClick={() => setOpen(null)}>{open?.locked ? "Close" : "Mark as studied"}</button>}>
        {open?.locked ? (
          <div className="text-center py-4">
            <Lock size={26} className="mx-auto text-[var(--text-muted)]" />
            <p className="text-[13px] text-[var(--text-muted)] mt-3 max-w-sm mx-auto">
              This resource unlocks after your teacher verifies the related roadmap tasks — it targets material you haven't covered yet.
            </p>
          </div>
        ) : (
          <p className="text-[13.5px] leading-6 text-[#3F4550]">{open?.summary} Work through it alongside the matching roadmap day for best effect.</p>
        )}
      </Modal>
    </div>
  );
}

function Analytics() {
  const roadmaps = useApp((s) => s.roadmaps);
  const roadmap = publishedForStudent(roadmaps, demoStudent.id);
  const mins = roadmap?.days.map((d) => ({ label: `D${d.dayNumber}`, value: d.tasks.reduce((a, t) => a + t.estimatedMinutes, 0) })) ?? [];
  return (
    <div>
      <SectionHead title="Analytics" desc="How your effort is distributed across the plan." />
      <div className="grid lg:grid-cols-2 gap-5">
        <FactorBarCard data={FACTOR_KEYS.map((k) => ({ label: FACTOR_LABELS[k], value: demoStudent.factors[k] }))} title="Strengths vs gaps" sub="Below 60% is where the plan focuses" />
        <div className="card p-5">
          <h3 className="font-display text-[15px] font-semibold mb-1">Planned minutes per day</h3>
          <p className="text-[12px] text-[var(--text-muted)] mb-4">From your published roadmap</p>
          <FactorBarChartInline data={mins} />
        </div>
      </div>
    </div>
  );
}

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
function FactorBarChartInline({ data }: { data: { label: string; value: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
        <CartesianGrid stroke="#EEF0F4" vertical={false} />
        <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9AA1AC" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11, fill: "#9AA1AC" }} axisLine={false} tickLine={false} />
        <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E7E9EE", fontSize: 12 }} formatter={(v) => [`${v} min`, "Planned"]} cursor={{ fill: "rgba(37,99,235,0.05)" }} />
        <Bar dataKey="value" fill="#2563EB" radius={[6, 6, 0, 0]} barSize={26} />
      </BarChart>
    </ResponsiveContainer>
  );
}

const KIND_ICON = { info: Bell, success: CheckCheck, warning: Bell, danger: Bell } as const;
function Notifications() {
  const readNotifs = useApp((s) => s.readNotifs);
  const markRead = useApp((s) => s.markNotifRead);
  const mine = notifications.filter((n) => n.audience === "student");
  const ref = useRef<HTMLDivElement>(null);
  useRowStagger(ref, []);
  return (
    <div>
      <SectionHead title="Notifications" desc="Everything that happened on your plan." right={
        <button className="btn btn-secondary btn-sm" onClick={() => mine.forEach((n) => markRead(n.id))}><CheckCheck size={13} /> Mark all read</button>
      } />
      <div ref={ref} className="space-y-2.5 max-w-3xl">
        {mine.map((n) => {
          const read = readNotifs.includes(n.id);
          return (
            <button key={n.id} onClick={() => markRead(n.id)} className={cn("table-row w-full text-left card p-4 flex items-start gap-3", !read && "border-l-4 border-l-[var(--accent)]")}>
              <span className={cn("w-9 h-9 rounded-[10px] grid place-items-center shrink-0",
                n.kind === "success" ? "bg-[var(--success-soft)] text-[var(--success)]" : n.kind === "warning" ? "bg-[var(--warning-soft)] text-[var(--warning)]" : n.kind === "danger" ? "bg-[var(--danger-soft)] text-[var(--danger)]" : "bg-[var(--accent-soft)] text-[var(--accent)]")}>
                {n.kind === "success" ? <CheckCheck size={16} /> : <KIND_ICON.info size={16} />}
              </span>
              <span className="flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="text-[13.5px] font-semibold">{n.title}</span>
                  <span className="text-[11px] text-[var(--text-muted)] shrink-0">{n.time}</span>
                </span>
                <span className="block text-[12.5px] text-[var(--text-muted)] mt-0.5">{n.body}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Profile() {
  return (
    <div>
      <SectionHead title="Profile" />
      <Card className="p-6 max-w-2xl">
        <div className="flex items-center gap-4">
          <Avatar name={demoStudent.name} color={demoStudent.color} size={56} />
          <div>
            <h3 className="font-display text-[18px] font-semibold">{demoStudent.name}</h3>
            <p className="text-[12.5px] text-[var(--text-muted)]">Roll {demoStudent.roll} · {demoStudent.className} · {demoStudent.branch} · Sem {demoStudent.semester}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
          {[["Branch", demoStudent.branch], ["Class", demoStudent.className], ["Semester", String(demoStudent.semester)], ["Roll no.", demoStudent.roll.split("-")[2]]].map(([k, v]) => (
            <div key={k} className="rounded-xl bg-[#f7f8fa] border border-[var(--border)] p-3">
              <div className="text-[11px] text-[var(--text-muted)] font-medium">{k}</div>
              <div className="text-[13.5px] font-semibold mt-0.5">{v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Settings() {
  const resetData = useApp((s) => s.resetData);
  const logout = useAuth((s) => s.logout);
  const [prefs, setPrefs] = useState({ digest: true, reminders: true, alerts: false });
  const Toggle = ({ k, label, desc }: { k: keyof typeof prefs; label: string; desc: string }) => (
    <div className="flex items-center justify-between py-3.5 border-b border-[var(--border)] last:border-0">
      <div><div className="text-[13.5px] font-semibold">{label}</div><div className="text-[12px] text-[var(--text-muted)]">{desc}</div></div>
      <button role="switch" aria-checked={prefs[k]} onClick={() => setPrefs((p) => ({ ...p, [k]: !p[k] }))}
        className={cn("w-10 h-6 rounded-full transition-colors relative", prefs[k] ? "bg-[var(--accent)]" : "bg-[#D5D9E0]")}>
        <span className={cn("absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all", prefs[k] ? "left-[18px]" : "left-0.5")} />
      </button>
    </div>
  );
  return (
    <div>
      <SectionHead title="Settings" />
      <div className="grid lg:grid-cols-2 gap-5 max-w-4xl">
        <Card className="p-5">
          <h3 className="font-display text-[15px] font-semibold mb-2">Notifications</h3>
          <Toggle k="digest" label="Weekly digest" desc="Summary of your prediction and progress every Monday" />
          <Toggle k="reminders" label="Task reminders" desc="Nudge me a day before a task is due" />
          <Toggle k="alerts" label="Prediction alerts" desc="Notify me when a new prediction run completes" />
        </Card>
        <Card className="p-5">
          <h3 className="font-display text-[15px] font-semibold mb-2">Data & session</h3>
          <p className="text-[12.5px] text-[var(--text-muted)] mb-4">This prototype keeps everything in your browser. Reset to restore the original seed data.</p>
          <div className="flex gap-2">
            <button className="btn btn-secondary" onClick={resetData}><RotateCcw size={14} /> Reset demo data</button>
            <button className="btn btn-danger" onClick={logout}>Sign out</button>
          </div>
        </Card>
      </div>
    </div>
  );
}

export default function StudentMisc({ page }: { page: string }) {
  switch (page) {
    case "subjects": return <Subjects />;
    case "performance": return <Performance />;
    case "resources": return <Resources />;
    case "analytics": return <Analytics />;
    case "notifications": return <Notifications />;
    case "profile": return <Profile />;
    case "settings": return <Settings />;
    default: return <EmptyState icon={Bell} title="Not found" desc="This page doesn't exist." />;
  }
}
