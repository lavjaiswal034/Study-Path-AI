import { ClipboardList, Send } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Card, EmptyState, Modal, Pill, SectionHead, TASK_STATUS, TYPE_META, PRIORITY, cn } from "../../components/ui";
import { demoStudent } from "../../data";
import { useRowStagger } from "../../lib/hooks";
import { tasksForStudent, useApp } from "../../store";
import type { RoadmapTask, TaskStatus } from "../../types";

type Filter = "all" | TaskStatus;

export default function StudentTasks() {
  const roadmaps = useApp((s) => s.roadmaps);
  const submitTask = useApp((s) => s.submitTask);
  const [filter, setFilter] = useState<Filter>("all");
  const [submitFor, setSubmitFor] = useState<{ task: RoadmapTask; day: number } | null>(null);
  const [text, setText] = useState("");
  const listRef = useRef<HTMLDivElement>(null);

  const rows = useMemo(
    () => tasksForStudent(roadmaps, demoStudent.id).map(({ day, task }) => ({ day, task })),
    [roadmaps],
  );
  const filtered = filter === "all" ? rows : rows.filter((r) => r.task.status === filter);
  const counts = (s: Filter) => (s === "all" ? rows.length : rows.filter((r) => r.task.status === s).length);

  useRowStagger(listRef, [filter]);

  const doSubmit = () => {
    if (!submitFor || text.trim().length < 10) return;
    submitTask(submitFor.task.id, text.trim());
    setSubmitFor(null);
    setText("");
  };

  const FILTERS: { key: Filter; label: string }[] = [
    { key: "all", label: "All" },
    { key: "not_started", label: "Not started" },
    { key: "submitted", label: "Submitted" },
    { key: "needs_revision", label: "Needs revision" },
    { key: "verified", label: "Verified" },
  ];

  return (
    <div>
      <SectionHead title="Tasks" desc="Everything on your published roadmap, with live status as teachers review your work." />

      <div className="flex items-center gap-1.5 flex-wrap mb-5">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "px-3 py-1.5 rounded-full text-[12.5px] font-semibold border transition-colors",
              filter === f.key ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-white border-[var(--border)] text-[var(--text-muted)] hover:text-[var(--text-primary)]",
            )}
          >
            {f.label} <span className="opacity-70 ml-0.5">{counts(f.key)}</span>
          </button>
        ))}
      </div>

      <div ref={listRef} className="space-y-3">
        {filtered.length === 0 && (
          <EmptyState icon={ClipboardList} title="No tasks here" desc="Nothing matches this filter right now. Check another status or come back after your next review." />
        )}
        {filtered.map(({ day, task: t }) => {
          const M = TYPE_META[t.type];
          const open = t.status === "not_started" || t.status === "needs_revision";
          return (
            <Card key={t.id} hover className="table-row p-4">
              <div className="flex flex-wrap items-start gap-3">
                <span className="w-10 h-10 rounded-xl bg-[#f0f2f6] text-[var(--text-muted)] grid place-items-center shrink-0"><M.icon size={17} /></span>
                <div className="flex-1 min-w-[220px]">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-[14px]">{t.title}</span>
                    <Pill tone={TASK_STATUS[t.status].tone}>{TASK_STATUS[t.status].label}</Pill>
                    <Pill tone={PRIORITY[t.priority].tone}>{PRIORITY[t.priority].label}</Pill>
                  </div>
                  <div className="text-[12px] text-[var(--text-muted)] mt-1">
                    {t.subject} · {M.label} · {t.estimatedMinutes} min · Day {day.dayNumber}
                  </div>
                  {t.teacherFeedback && (
                    <p className={cn("mt-2.5 text-[12.5px] rounded-lg px-3 py-2 border", t.status === "verified" ? "bg-[var(--success-soft)] border-[#BFE8CC] text-[#166534]" : "bg-[var(--warning-soft)] border-[#F4DFB6] text-[#92400E]")}>
                      <span className="font-semibold">{t.status === "verified" ? "Verified" : "Feedback"}:</span> {t.teacherFeedback}
                      {t.marks && <span className="ml-2 font-bold">{t.marks.awarded}/{t.marks.outOf}</span>}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {open && (
                    <button className="btn btn-primary btn-sm" onClick={() => { setSubmitFor({ task: t, day: day.dayNumber }); setText(""); }}>
                      <Send size={13} /> {t.status === "needs_revision" ? "Resubmit" : "Submit"}
                    </button>
                  )}
                  {t.status === "submitted" && <span className="text-[11.5px] text-[var(--text-muted)]">Awaiting review</span>}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <Modal
        open={!!submitFor}
        onClose={() => setSubmitFor(null)}
        title={submitFor ? `Submit — ${submitFor.task.title}` : ""}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setSubmitFor(null)}>Cancel</button>
            <button className="btn btn-primary" disabled={text.trim().length < 10} onClick={doSubmit}>
              <Send size={14} /> Submit for review
            </button>
          </>
        }
      >
        <p className="text-[12.5px] text-[var(--text-muted)] mb-3">
          Day {submitFor?.day} · {submitFor?.task.subject}. Your teacher will verify this submission or return it with feedback.
        </p>
        <label className="label">Submission notes</label>
        <textarea className="textarea" rows={5} value={text} onChange={(e) => setText(e.target.value)} placeholder="Describe what you completed, what you found hard, and anything the reviewer should check…" />
        <p className={cn("text-[11.5px] mt-1.5", text.trim().length < 10 ? "text-[var(--text-muted)]" : "text-[var(--success)]")}>
          {text.trim().length < 10 ? "Add a little detail so your teacher can review properly." : "Looks good — ready to submit."}
        </p>
      </Modal>
    </div>
  );
}
