import { Brain, History, ShieldAlert } from "lucide-react";
import { useRef } from "react";
import { FactorBarCard, TrendChart } from "../../components/charts";
import { Card, Pill, ProgressBar, SectionHead, cn } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, demoStudent, predictions } from "../../data";
import { riskCategory } from "../../lib/ai";
import { useEnterStagger, useRowStagger } from "../../lib/hooks";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });

export default function StudentPredictions() {
  const scope = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLDivElement>(null);
  const current = predictions[0];
  const history = predictions.filter((p) => p.studentId === demoStudent.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const risk = riskCategory(current.predictedPct);

  useEnterStagger(scope, ".anim");
  useRowStagger(tableRef, []);

  return (
    <div ref={scope}>
      <SectionHead
        title="Predictions"
        desc="What ML model E46_V1 expects, and why. Friendly factor labels only — internal feature IDs stay hidden."
        right={<Pill tone={risk.tone}>{risk.label}</Pill>}
      />

      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-5 mb-5">
        <Card className="anim p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-[15px] font-semibold">Current prediction</h3>
              <p className="text-[12px] text-[var(--text-muted)]">Model {current.modelVersion} · feature set {current.featureSetVersion} · {fmt(current.createdAt)}</p>
            </div>
            <div className="text-right">
              <div className="font-display text-[30px] font-bold leading-none tabular-nums">{current.predictedPct}%</div>
              <div className="text-[11.5px] text-[var(--text-muted)] mt-1">{current.predictedMarks}/{current.maxMarks} marks</div>
            </div>
          </div>
          <div className="space-y-3">
            {FACTOR_KEYS.map((k) => {
              const v = current.factors[k];
              return (
                <div key={k} className="grid grid-cols-[150px_1fr_auto] items-center gap-3">
                  <span className="text-[12.5px] font-medium text-[#3F4550]">{FACTOR_LABELS[k]}</span>
                  <ProgressBar value={v} tone={v < 60 ? "warning" : v >= 80 ? "success" : "accent"} />
                  <span className={cn("text-[12.5px] font-bold tabular-nums w-10 text-right", v < 60 ? "text-[var(--warning)]" : "text-[var(--text-primary)]")}>{v}%</span>
                </div>
              );
            })}
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[11.5px] text-[var(--text-muted)]">
            <ShieldAlert size={13} className="text-[var(--warning)]" />
            {current.dataStatus === "verified" ? "Built on teacher-verified data." : "Built on unverified data — a teacher review will firm this number up."}
          </div>
        </Card>

        <div className="anim">
          <FactorBarCard data={FACTOR_KEYS.map((k) => ({ label: FACTOR_LABELS[k], value: current.factors[k] }))} title="Factor breakdown" sub="Where the marks are won and lost" />
        </div>
      </div>

      <Card className="anim p-0 overflow-hidden mb-5">
        <div className="flex items-center gap-2 px-5 pt-5 pb-3">
          <History size={16} className="text-[var(--text-muted)]" />
          <h3 className="font-display text-[15px] font-semibold">Prediction history</h3>
          <span className="text-[11.5px] text-[var(--text-muted)] ml-1">append-only — earlier runs are never overwritten</span>
        </div>
        <div ref={tableRef} className="overflow-x-auto scroll-thin">
          <table className="table">
            <thead>
              <tr>
                <th>Date</th><th>Predicted</th><th>Marks</th><th>Feature set</th><th>Data status</th>
              </tr>
            </thead>
            <tbody>
              {history.map((p) => (
                <tr key={p.id} className="table-row">
                  <td className="font-medium">{fmt(p.createdAt)}</td>
                  <td className="font-bold tabular-nums">{p.predictedPct}%</td>
                  <td className="tabular-nums text-[var(--text-muted)]">{p.predictedMarks} / {p.maxMarks}</td>
                  <td>{p.featureSetVersion}</td>
                  <td><Pill tone={p.dataStatus === "verified" ? "success" : "warning"}>{p.dataStatus === "verified" ? "Verified" : "Unverified"}</Pill></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="anim">
        <TrendChart data={[...history].reverse().map((p) => ({ label: fmt(p.createdAt).replace(" ", " "), pct: p.predictedPct, status: p.dataStatus }))} />
      </div>

      <p className="mt-5 text-[11.5px] text-[var(--text-muted)] flex items-center gap-1.5">
        <Brain size={13} /> These numbers are model output, not AI-written text. No confidence scores are shown or invented.
      </p>
    </div>
  );
}
