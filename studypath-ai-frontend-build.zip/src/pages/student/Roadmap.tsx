import { AnimatePresence, motion } from "framer-motion";
import { Award, Flame, MapPinned, Route, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import PathCanvas, { dayState } from "../../components/PathCanvas";
import { Card, EmptyState, Pill, TYPE_META, TASK_STATUS, cn } from "../../components/ui";
import { demoStudent } from "../../data";
import { publishedForStudent, useApp } from "../../store";

function Ring({ pct }: { pct: number }) {
  const r = 20, c = 2 * Math.PI * r;
  return (
    <svg width="52" height="52" viewBox="0 0 52 52" className="-rotate-90">
      <circle cx="26" cy="26" r={r} fill="none" stroke="#EEF0F4" strokeWidth="6" />
      <circle cx="26" cy="26" r={r} fill="none" stroke="var(--path-purple)" strokeWidth="6" strokeLinecap="round"
        strokeDasharray={c} strokeDashoffset={c - (c * pct) / 100} style={{ transition: "stroke-dashoffset 1s ease" }} />
    </svg>
  );
}

export default function StudentRoadmap() {
  const roadmaps = useApp((s) => s.roadmaps);
  const navigate = useApp((s) => s.navigate);
  const roadmap = publishedForStudent(roadmaps, demoStudent.id);
  const [selected, setSelected] = useState(() => {
    if (!roadmap) return 0;
    const i = roadmap.days.findIndex((d) => dayState(d) === "active");
    return i >= 0 ? i : 0;
  });

  const allTasks = useMemo(() => (roadmap ? roadmap.days.flatMap((d) => d.tasks) : []), [roadmap]);
  const verified = allTasks.filter((t) => t.status === "verified").length;
  const points = allTasks.reduce((acc, t) => acc + (t.status === "verified" ? 20 : t.status === "submitted" ? 5 : 0), 0);
  const progress = allTasks.length ? Math.round((verified / allTasks.length) * 100) : 0;

  if (!roadmap) {
    return (
      <div className="max-w-2xl mx-auto mt-10">
        <EmptyState
          icon={Route}
          title="No roadmap published yet"
          desc="Your teacher hasn't published a learning roadmap for you. Once they approve a draft — manual or AI-generated — your path appears here."
          action={<button className="btn btn-secondary" onClick={() => navigate("dashboard")}>Back to dashboard</button>}
        />
      </div>
    );
  }

  const day = roadmap.days[selected];

  return (
    <div>
      {/* gamified header */}
      <div className="card p-5 mb-6 bg-gradient-to-r from-[#17122B] to-[#101828] border-0 text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 rounded-full bg-[rgba(124,58,237,0.25)] blur-3xl" aria-hidden="true" />
        <div className="relative flex flex-wrap items-center gap-x-8 gap-y-4">
          <div>
            <div className="text-[11px] font-bold tracking-widest text-[#B9A6FF] uppercase flex items-center gap-1.5"><MapPinned size={12} /> Your learning path</div>
            <h1 className="font-display text-[24px] font-bold mt-1">{roadmap.subject}</h1>
            <p className="text-[12.5px] text-white/60 mt-0.5">Focus: {roadmap.priorityFocus} · {roadmap.durationDays}-day plan · AI-generated draft, teacher-approved</p>
          </div>
          <div className="ml-auto flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="w-9 h-9 rounded-full bg-[rgba(217,119,6,0.2)] text-[#FFB454] grid place-items-center"><Flame size={17} /></span>
              <div><div className="font-display text-[18px] font-bold leading-none">4</div><div className="text-[10.5px] text-white/55">day streak</div></div>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-9 h-9 rounded-full bg-[rgba(124,58,237,0.25)] text-[#C4AFFF] grid place-items-center"><Award size={17} /></span>
              <div><div className="font-display text-[18px] font-bold leading-none tabular-nums">{points}</div><div className="text-[10.5px] text-white/55">points</div></div>
            </div>
            <div className="relative grid place-items-center">
              <Ring pct={progress} />
              <span className="absolute text-[11px] font-bold tabular-nums">{progress}%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[minmax(0,460px)_1fr] gap-6 items-start">
        <Card className="p-5">
          <PathCanvas days={roadmap.days} selectedIndex={selected} onSelect={setSelected} studentInitial={demoStudent.name[0]} />
        </Card>

        <div>
          <AnimatePresence mode="wait">
            <motion.div
              key={day.id}
              initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.25 }}
            >
              <Card className="p-5">
                <div className="flex items-center justify-between mb-1">
                  <span className="pill pill-purple">Day {day.dayNumber}</span>
                  <Pill tone={dayState(day) === "completed" ? "success" : dayState(day) === "active" ? "purple" : "muted"}>
                    {dayState(day) === "completed" ? "Completed" : dayState(day) === "active" ? "In progress" : "Locked"}
                  </Pill>
                </div>
                <h2 className="font-display text-[20px] font-semibold">{day.title}</h2>
                <p className="text-[12.5px] text-[var(--text-muted)] mb-4">
                  {day.tasks.reduce((a, t) => a + t.estimatedMinutes, 0)} min total · {day.tasks.length} tasks
                </p>
                <div className="space-y-3">
                  {day.tasks.map((t) => {
                    const M = TYPE_META[t.type];
                    return (
                      <div key={t.id} className="flex items-start gap-3 p-3.5 rounded-xl border border-[var(--border)] bg-[#FBFCFD]">
                        <span className="w-9 h-9 rounded-[10px] bg-[var(--purple-soft)] text-[var(--path-purple)] grid place-items-center shrink-0"><M.icon size={16} /></span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[13.5px] font-semibold">{t.title}</span>
                            <Pill tone={TASK_STATUS[t.status].tone}>{TASK_STATUS[t.status].label}</Pill>
                          </div>
                          <div className="text-[11.5px] text-[var(--text-muted)] mt-1">{M.label} · {t.priority} priority · {t.estimatedMinutes} min</div>
                          {t.teacherFeedback && (
                            <p className="mt-2 text-[12px] text-[#3F4550] bg-[var(--warning-soft)] border border-[#F4DFB6] rounded-lg px-3 py-2">
                              <span className="font-semibold text-[var(--warning)]">Teacher:</span> {t.teacherFeedback}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <button className={cn("btn btn-accent w-full mt-4")} onClick={() => navigate("tasks")}>
                  <Sparkles size={15} /> Work on tasks
                </button>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
