import { ArrowRight, Brain, CalendarDays, ClipboardList, FlaskConical, GraduationCap, ListChecks, Route, Sparkles } from "lucide-react";
import { useRef, useState } from "react";
import { TrendChart } from "../../components/charts";
import { Card, Pill, ProgressBar, SectionHead, StatCard, TASK_STATUS, TYPE_META, cn } from "../../components/ui";
import { FACTOR_KEYS, FACTOR_LABELS, demoStudent, predictions } from "../../data";
import { aiSummary, riskCategory, weakAreas } from "../../lib/ai";
import { useEnterStagger } from "../../lib/hooks";
import { publishedForStudent, useApp } from "../../store";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short" });

export default function StudentDashboard() {
  const navigate = useApp((s) => s.navigate);
  const roadmaps = useApp((s) => s.roadmaps);
  const scope = useRef<HTMLDivElement>(null);
  const [summaryVariant, setSummaryVariant] = useState(0);

  const prediction = predictions[0];
  const risk = riskCategory(prediction.predictedPct);
  const weak = weakAreas(prediction.factors, 2);
  const roadmap = publishedForStudent(roadmaps, demoStudent.id);
  const upcoming = roadmap ? roadmap.days.flatMap((d) => d.tasks).filter((t) => t.status !== "verified").slice(0, 3) : [];
  const history = predictions.filter((p) => p.studentId === demoStudent.id).sort((a, b) => a.createdAt.localeCompare(b.createdAt));

  const leads = [
    aiSummary(prediction.predictedPct, prediction.factors),
    `Focus window: the next two weeks matter most. ${weak[0].label} at ${weak[0].value}% is the single highest-leverage area — small, consistent gains there compound into the predicted score. Keep leaning on your strongest signals so they stay reliable.`,
    `Compared to classmates, your profile is middle-of-the-pack with a clear ceiling break available. Predicted ${prediction.predictedPct}% is not a verdict — it is the expected outcome if nothing changes. The roadmap below is the change.`,
  ];

  useEnterStagger(scope, ".stat-card, .dash-card");

  return (
    <div ref={scope}>
      <SectionHead
        title={`Welcome back, ${demoStudent.name.split(" ")[0]}`}
        desc={`${demoStudent.className} · ${demoStudent.branch} · Semester ${demoStudent.semester} · ${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}`}
      />

      {/* hero prediction */}
      <Card className="dash-card p-6 mb-5 overflow-hidden relative">
        <div className="absolute -right-16 -top-16 w-56 h-56 rounded-full bg-[var(--accent-soft)]" aria-hidden="true" />
        <div className="relative grid md:grid-cols-[auto_1fr] gap-6 items-center">
          <div className="flex items-center gap-6">
            <div>
              <div className="text-[12px] font-semibold text-[var(--text-muted)] uppercase tracking-wide">Predicted outcome</div>
              <div className="font-display text-[56px] font-bold leading-none mt-1 tabular-nums">
                {prediction.predictedPct}
                <span className="text-[24px] text-[var(--text-muted)] font-semibold">%</span>
              </div>
              <div className="mt-2 text-[13px] text-[var(--text-muted)]">
                ≈ <span className="font-semibold text-[var(--text-primary)]">{prediction.predictedMarks}</span> of {prediction.maxMarks} marks
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                <Pill tone="dark"><Brain size={11} /> ML Model {prediction.modelVersion}</Pill>
                <Pill tone={prediction.dataStatus === "verified" ? "success" : "warning"}>
                  {prediction.dataStatus === "verified" ? "Verified data" : "Unverified data"}
                </Pill>
                <Pill tone={risk.tone}>{risk.label}</Pill>
              </div>
            </div>
          </div>

          <div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-5 gap-y-3.5">
              {FACTOR_KEYS.map((k) => (
                <div key={k}>
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-[11.5px] font-medium text-[var(--text-muted)]">{FACTOR_LABELS[k]}</span>
                    <span className={cn("text-[12px] font-bold tabular-nums", prediction.factors[k] < 60 ? "text-[var(--warning)]" : "text-[var(--text-primary)]")}>
                      {prediction.factors[k]}%
                    </span>
                  </div>
                  <ProgressBar value={prediction.factors[k]} tone={prediction.factors[k] < 60 ? "warning" : "accent"} />
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <button className="btn btn-primary" onClick={() => navigate("roadmap")}>
                <Route size={15} /> Open AI Roadmap <ArrowRight size={14} />
              </button>
              <button className="btn btn-secondary" onClick={() => navigate("predictions")}>Prediction history</button>
              <span className="text-[11.5px] text-[var(--text-muted)] ml-1">Generated {fmt(prediction.createdAt)} · features {prediction.featureSetVersion}</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        {/* AI Gateway summary */}
        <Card className="dash-card lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-[9px] bg-[var(--accent-soft)] text-[var(--accent)] grid place-items-center"><Sparkles size={15} /></span>
              <div>
                <h3 className="font-display text-[14.5px] font-semibold leading-tight">AI Gateway summary</h3>
                <p className="text-[11px] text-[var(--text-muted)]">Generated explanation · not the prediction itself</p>
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => setSummaryVariant((v) => (v + 1) % leads.length)}>
              <Sparkles size={13} /> Regenerate
            </button>
          </div>
          <p key={summaryVariant} className="text-[13.5px] leading-6 text-[#3F4550]">{leads[summaryVariant]}</p>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          <StatCard icon={CalendarDays} label="Attendance" value={prediction.factors.attendancePct} suffix="%" tone="accent" />
          <StatCard icon={ClipboardList} label="Assignments" value={prediction.factors.assignmentAvg} suffix="%" tone="success" />
          <StatCard icon={ListChecks} label="Quiz average" value={prediction.factors.quizAvg} suffix="%" tone={prediction.factors.quizAvg < 60 ? "warning" : "accent"} />
          <StatCard icon={FlaskConical} label="Laboratory" value={prediction.factors.laboratory} suffix="%" tone="success" />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <Card className="dash-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-[15px] font-semibold">Up next on your roadmap</h3>
            <button className="btn btn-ghost btn-sm" onClick={() => navigate("tasks")}>All tasks <ArrowRight size={13} /></button>
          </div>
          <div className="space-y-2.5">
            {upcoming.length === 0 && <p className="text-[13px] text-[var(--text-muted)]">Nothing pending — nice work.</p>}
            {upcoming.map((t) => {
              const M = TYPE_META[t.type];
              return (
                <button key={t.id} onClick={() => navigate("tasks")} className="w-full flex items-center gap-3 p-3 rounded-xl border border-[var(--border)] hover:border-[#c9ced8] hover:bg-[#fafbfd] transition-colors text-left">
                  <span className="w-9 h-9 rounded-[10px] bg-[#f0f2f6] grid place-items-center text-[var(--text-muted)]"><M.icon size={16} /></span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-[13px] font-semibold truncate">{t.title}</span>
                    <span className="block text-[11.5px] text-[var(--text-muted)]">{M.label} · {t.estimatedMinutes} min</span>
                  </span>
                  <Pill tone={TASK_STATUS[t.status].tone}>{TASK_STATUS[t.status].label}</Pill>
                </button>
              );
            })}
          </div>
        </Card>

        <div className="dash-card">
          <TrendChart data={history.map((p) => ({ label: fmt(p.createdAt), pct: p.predictedPct, status: p.dataStatus }))} />
        </div>
      </div>

      <p className="mt-5 text-[11.5px] text-[var(--text-muted)] flex items-center gap-1.5">
        <GraduationCap size={13} /> The number above comes from ML model E46_V1. Roadmaps and explanations are drafted separately by the AI Gateway and always arrive as drafts.
      </p>
    </div>
  );
}
