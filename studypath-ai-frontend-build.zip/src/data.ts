import type {
  AppNotification,
  FactorKey,
  LearningResource,
  Prediction,
  RoadmapDraft,
  Student,
  TeacherUser,
} from "./types";

/* ------------------------------------------------------------------ */
/* Friendly label map — internal feature IDs are NEVER shown in the UI */
/* ------------------------------------------------------------------ */
export const FACTOR_LABELS: Record<FactorKey, string> = {
  attendancePct: "Attendance",
  assessmentAvg: "Assessment Average",
  assignmentAvg: "Assignment Average",
  quizAvg: "Quiz Average",
  laboratory: "Laboratory",
  internalAssessment: "Internal Assessment",
};

export const FACTOR_KEYS: FactorKey[] = [
  "attendancePct",
  "assessmentAvg",
  "assignmentAvg",
  "quizAvg",
  "laboratory",
  "internalAssessment",
];

export const SUBJECTS = ["Data Structures", "DBMS", "Operating Systems", "Mathematics III", "Computer Organization"];

/* ------------------------------------------------------------------ */
/* Students                                                            */
/* ------------------------------------------------------------------ */
export const students: Student[] = [
  {
    id: "s_rahul", name: "Rahul Kumar", roll: "CSE-3A-21", className: "CSE-3A", branch: "CSE", semester: 5, color: "#2563EB",
    factors: { attendancePct: 84, assessmentAvg: 76, assignmentAvg: 81, quizAvg: 68, laboratory: 79, internalAssessment: 74 },
    subjects: [
      { name: "Data Structures", grade: "B+", pct: 72 },
      { name: "DBMS", grade: "A", pct: 82 },
      { name: "Operating Systems", grade: "B", pct: 68 },
      { name: "Mathematics III", grade: "B+", pct: 71 },
    ],
  },
  {
    id: "s_priya", name: "Priya Sharma", roll: "CSE-3A-08", className: "CSE-3A", branch: "CSE", semester: 5, color: "#0EA5E9",
    factors: { attendancePct: 96, assessmentAvg: 88, assignmentAvg: 92, quizAvg: 84, laboratory: 90, internalAssessment: 89 },
    subjects: [
      { name: "Data Structures", grade: "A", pct: 89 },
      { name: "DBMS", grade: "A", pct: 91 },
      { name: "Operating Systems", grade: "A-", pct: 85 },
    ],
  },
  {
    id: "s_arjun", name: "Arjun Mehta", roll: "CSE-3A-04", className: "CSE-3A", branch: "CSE", semester: 5, color: "#16A34A",
    factors: { attendancePct: 78, assessmentAvg: 64, assignmentAvg: 70, quizAvg: 58, laboratory: 72, internalAssessment: 66 },
    subjects: [{ name: "Data Structures", grade: "B", pct: 65 }],
  },
  {
    id: "s_neha", name: "Neha Gupta", roll: "CSE-3A-14", className: "CSE-3A", branch: "CSE", semester: 5, color: "#D97706",
    factors: { attendancePct: 91, assessmentAvg: 80, assignmentAvg: 77, quizAvg: 74, laboratory: 83, internalAssessment: 79 },
    subjects: [{ name: "Data Structures", grade: "B+", pct: 78 }],
  },
  {
    id: "s_karan", name: "Karan Singh", roll: "CSE-3A-11", className: "CSE-3A", branch: "CSE", semester: 5, color: "#DC2626",
    factors: { attendancePct: 58, assessmentAvg: 44, assignmentAvg: 52, quizAvg: 40, laboratory: 55, internalAssessment: 47 },
    subjects: [{ name: "Data Structures", grade: "C", pct: 46 }],
  },
  {
    id: "s_anya", name: "Anya Iyer", roll: "CSE-3A-02", className: "CSE-3A", branch: "CSE", semester: 5, color: "#7C3AED",
    factors: { attendancePct: 88, assessmentAvg: 74, assignmentAvg: 85, quizAvg: 70, laboratory: 80, internalAssessment: 76 },
    subjects: [{ name: "Data Structures", grade: "B+", pct: 76 }],
  },
  {
    id: "s_dev", name: "Dev Patel", roll: "CSE-3B-07", className: "CSE-3B", branch: "CSE", semester: 5, color: "#0891B2",
    factors: { attendancePct: 82, assessmentAvg: 71, assignmentAvg: 75, quizAvg: 66, laboratory: 77, internalAssessment: 72 },
    subjects: [{ name: "Data Structures", grade: "B", pct: 70 }],
  },
  {
    id: "s_meera", name: "Meera Nair", roll: "CSE-3B-12", className: "CSE-3B", branch: "CSE", semester: 5, color: "#DB2777",
    factors: { attendancePct: 93, assessmentAvg: 85, assignmentAvg: 88, quizAvg: 81, laboratory: 87, internalAssessment: 84 },
    subjects: [{ name: "Data Structures", grade: "A", pct: 86 }],
  },
];

export const demoStudent = students[0];

/* ------------------------------------------------------------------ */
/* Teachers                                                            */
/* ------------------------------------------------------------------ */
export const teachers: TeacherUser[] = [
  { id: "t_kavita", name: "Ms. Kavita Rao", role: "class_teacher", className: "CSE-3A", subjects: SUBJECTS },
  { id: "t_anand", name: "Mr. Anand Verma", role: "subject_teacher", subjects: ["Data Structures"] },
  { id: "t_rita", name: "Dr. Rita Bose", role: "subject_teacher", subjects: ["DBMS"] },
];

/* ------------------------------------------------------------------ */
/* Predictions — history is append-only, never overwritten             */
/* ------------------------------------------------------------------ */
const daysAgo = (n: number) => new Date(Date.now() - n * 86400000).toISOString();

export const predictions: Prediction[] = [
  {
    id: "p_1", studentId: "s_rahul", predictedPct: 72.4, predictedMarks: 36.2, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "unverified", verifiedDataUsed: false,
    factors: { attendancePct: 84, assessmentAvg: 76, assignmentAvg: 81, quizAvg: 68, laboratory: 79, internalAssessment: 74 },
    createdAt: daysAgo(0),
  },
  {
    id: "p_r2", studentId: "s_rahul", predictedPct: 68.9, predictedMarks: 34.5, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "verified", verifiedDataUsed: true,
    factors: { attendancePct: 82, assessmentAvg: 72, assignmentAvg: 78, quizAvg: 63, laboratory: 76, internalAssessment: 71 },
    createdAt: daysAgo(21),
  },
  {
    id: "p_r3", studentId: "s_rahul", predictedPct: 64.2, predictedMarks: 32.1, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v2", dataStatus: "verified", verifiedDataUsed: true,
    factors: { attendancePct: 79, assessmentAvg: 68, assignmentAvg: 74, quizAvg: 58, laboratory: 72, internalAssessment: 67 },
    createdAt: daysAgo(45),
  },
  {
    id: "p_r4", studentId: "s_rahul", predictedPct: 61.5, predictedMarks: 30.8, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v2", dataStatus: "verified", verifiedDataUsed: true,
    factors: { attendancePct: 76, assessmentAvg: 65, assignmentAvg: 71, quizAvg: 55, laboratory: 70, internalAssessment: 64 },
    createdAt: daysAgo(70),
  },
  {
    id: "p_priya", studentId: "s_priya", predictedPct: 90.2, predictedMarks: 45.1, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "verified", verifiedDataUsed: true,
    factors: students[1].factors, createdAt: daysAgo(3),
  },
  {
    id: "p_arjun", studentId: "s_arjun", predictedPct: 63.8, predictedMarks: 31.9, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "unverified", verifiedDataUsed: false,
    factors: students[2].factors, createdAt: daysAgo(2),
  },
  {
    id: "p_neha", studentId: "s_neha", predictedPct: 79.6, predictedMarks: 39.8, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "verified", verifiedDataUsed: true,
    factors: students[3].factors, createdAt: daysAgo(4),
  },
  {
    id: "p_karan", studentId: "s_karan", predictedPct: 45.9, predictedMarks: 23.0, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "unverified", verifiedDataUsed: false,
    factors: students[4].factors, createdAt: daysAgo(1),
  },
  {
    id: "p_anya", studentId: "s_anya", predictedPct: 77.1, predictedMarks: 38.6, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "verified", verifiedDataUsed: true,
    factors: students[5].factors, createdAt: daysAgo(5),
  },
  {
    id: "p_dev", studentId: "s_dev", predictedPct: 71.3, predictedMarks: 35.7, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "unverified", verifiedDataUsed: false,
    factors: students[6].factors, createdAt: daysAgo(6),
  },
  {
    id: "p_meera", studentId: "s_meera", predictedPct: 86.4, predictedMarks: 43.2, maxMarks: 50,
    modelVersion: "E46_V1", featureSetVersion: "v3", dataStatus: "verified", verifiedDataUsed: true,
    factors: students[7].factors, createdAt: daysAgo(7),
  },
];

export const demoPrediction = predictions[0];

export const latestPredictionFor = (studentId: string) =>
  predictions.filter((p) => p.studentId === studentId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];

/* ------------------------------------------------------------------ */
/* Roadmaps — tasks seeded across every status                         */
/* ------------------------------------------------------------------ */
const T = (
  id: string, title: string, subject: string, type: RoadmapDraft["days"][0]["tasks"][0]["type"],
  priority: "low" | "medium" | "high", mins: number, status: RoadmapDraft["days"][0]["tasks"][0]["status"],
  extra: Partial<RoadmapDraft["days"][0]["tasks"][0]> = {},
) => ({
  id, title, subject, type, priority, estimatedMinutes: mins, status,
  assignTo: { scope: "student" as const, ids: ["s_rahul"] }, ...extra,
});

export const seedRoadmaps: RoadmapDraft[] = [
  {
    id: "rm_pub",
    studentId: "s_rahul",
    subject: "Data Structures",
    predictionId: "p_1",
    priorityFocus: "Quiz Average · Internal Assessment",
    durationDays: 7,
    status: "published",
    source: "ai_generated",
    createdAt: daysAgo(6),
    days: [
      {
        id: "d1", dayNumber: 1, title: "Foundations Refresh",
        tasks: [
          T("t1", "Revise arrays & linked lists", "Data Structures", "study", "medium", 40, "verified", { marks: { awarded: 9, outOf: 10 }, teacherFeedback: "Solid recap — clean notes." }),
          T("t2", "Big-O practice set", "Data Structures", "practice", "high", 30, "verified", { marks: { awarded: 8, outOf: 10 }, teacherFeedback: "Good. Watch edge cases on nested loops." }),
        ],
      },
      {
        id: "d2", dayNumber: 2, title: "Stacks & Queues",
        tasks: [
          T("t3", "Stack operations walkthrough", "Data Structures", "study", "medium", 35, "verified", { marks: { awarded: 9, outOf: 10 } }),
          T("t4", "Queue quiz — timed", "Data Structures", "quiz", "high", 25, "needs_revision", { teacherFeedback: "Circular queue logic is off — re-attempt Q3–Q5 and resubmit." }),
        ],
      },
      {
        id: "d3", dayNumber: 3, title: "Recursion & Trees",
        tasks: [
          T("t5", "Tree traversal lab", "Data Structures", "practice", "high", 45, "submitted"),
          T("t6", "Recursion trace worksheet", "Data Structures", "assignment", "medium", 30, "not_started"),
        ],
      },
      {
        id: "d4", dayNumber: 4, title: "Graph Basics",
        tasks: [
          T("t7", "BFS/DFS study notes", "Data Structures", "study", "high", 40, "not_started"),
          T("t8", "Graph quiz", "Data Structures", "quiz", "medium", 20, "not_started"),
        ],
      },
      {
        id: "d5", dayNumber: 5, title: "Hashing",
        tasks: [T("t9", "Hash tables & collisions", "Data Structures", "study", "medium", 35, "not_started")],
      },
      {
        id: "d6", dayNumber: 6, title: "Mixed Practice",
        tasks: [T("t10", "Previous-year problem set", "Data Structures", "practice", "high", 50, "not_started")],
      },
      {
        id: "d7", dayNumber: 7, title: "Full Revision & Mock",
        tasks: [
          T("t11", "Formula & complexity sheet review", "Data Structures", "study", "low", 25, "not_started"),
          T("t12", "Mock test — 50 marks", "Data Structures", "quiz", "high", 60, "not_started"),
        ],
      },
    ],
  },
  {
    id: "rm_draft_priya",
    studentId: "s_priya",
    subject: "Data Structures",
    predictionId: "p_priya",
    priorityFocus: "Advanced graphs",
    durationDays: 3,
    status: "draft",
    source: "manual",
    createdAt: daysAgo(1),
    days: [
      {
        id: "pd1", dayNumber: 1, title: "Graph algorithms",
        tasks: [T("pt1", "Dijkstra & Bellman-Ford", "Data Structures", "study", "medium", 45, "not_started", { assignTo: { scope: "student", ids: ["s_priya"] } })],
      },
    ],
  },
];

export const seedSubmissions: Record<string, string> = {
  t5: "Implemented inorder, preorder and postorder traversals recursively and iteratively. Attached complexity table and output screenshots for the sample BST. Struggled a bit with iterative postorder — added extra comments there.",
};

/* ------------------------------------------------------------------ */
/* Notifications                                                       */
/* ------------------------------------------------------------------ */
export const notifications: AppNotification[] = [
  { id: "n1", audience: "student", title: "Task returned for revision", body: "“Queue quiz — timed” was reviewed. Open Tasks to see feedback and resubmit.", time: "2h ago", kind: "warning" },
  { id: "n2", audience: "student", title: "New prediction available", body: "Model E46_V1 generated a new performance prediction for Data Structures.", time: "1d ago", kind: "info" },
  { id: "n3", audience: "student", title: "Task verified", body: "“Stack operations walkthrough” was verified with 9/10.", time: "2d ago", kind: "success" },
  { id: "n4", audience: "class_teacher", title: "3 submissions awaiting review", body: "Students in CSE-3A have submitted tasks that need verification.", time: "1h ago", kind: "warning" },
  { id: "n5", audience: "class_teacher", title: "At-risk flag", body: "Karan Singh's predicted score dropped below 50%. Consider a roadmap.", time: "5h ago", kind: "danger" },
  { id: "n6", audience: "subject_teacher", title: "New submission", body: "Rahul Kumar submitted “Tree traversal lab” for Data Structures.", time: "3h ago", kind: "info" },
  { id: "n7", audience: "admin", title: "Model E46_V1 batch complete", body: "Nightly prediction batch processed 248 students, 0 failures.", time: "6h ago", kind: "success" },
];

/* ------------------------------------------------------------------ */
/* Learning resources                                                  */
/* ------------------------------------------------------------------ */
export const resources: LearningResource[] = [
  { id: "r1", title: "Linked Lists, visually explained", subject: "Data Structures", kind: "video", minutes: 14, summary: "Pointer-by-pointer animation of insertion, deletion and reversal with complexity notes." },
  { id: "r2", title: "Stack & Queue cheat-sheet", subject: "Data Structures", kind: "notes", minutes: 6, summary: "One-page reference covering operations, complexities and classic interview patterns." },
  { id: "r3", title: "Tree traversals — recursive vs iterative", subject: "Data Structures", kind: "article", minutes: 11, summary: "Side-by-side implementations with a walkthrough of the explicit-stack technique." },
  { id: "r4", title: "Graph algorithms problem set", subject: "Data Structures", kind: "problem-set", minutes: 45, summary: "12 graded problems on BFS, DFS, topological sort and shortest paths.", locked: true },
  { id: "r5", title: "Hashing & collision handling", subject: "Data Structures", kind: "video", minutes: 18, summary: "Chaining vs open addressing with load-factor analysis and resizing strategies." },
  { id: "r6", title: "Normal forms worked examples", subject: "DBMS", kind: "notes", minutes: 9, summary: "1NF→BCNF decomposition examples taken from past university papers." },
];

/* ------------------------------------------------------------------ */
/* Admin seed rows                                                     */
/* ------------------------------------------------------------------ */
export const adminSeed = {
  users: [
    { id: "u1", name: "Dr. S. Menon", email: "admin@studypath.edu", role: "Admin", status: "Active" },
    { id: "u2", name: "Ms. Kavita Rao", email: "kavita@studypath.edu", role: "Class Teacher", status: "Active" },
    { id: "u3", name: "Mr. Anand Verma", email: "anand@studypath.edu", role: "Subject Teacher", status: "Active" },
    { id: "u4", name: "Rahul Kumar", email: "rahul@student.edu", role: "Student", status: "Active" },
    { id: "u5", name: "Karan Singh", email: "karan@student.edu", role: "Student", status: "Suspended" },
  ],
  classes: [
    { id: "c1", name: "CSE-3A", branch: "CSE", semester: 5, teacher: "Ms. Kavita Rao", strength: 62 },
    { id: "c2", name: "CSE-3B", branch: "CSE", semester: 5, teacher: "Dr. Rita Bose", strength: 58 },
    { id: "c3", name: "ECE-2A", branch: "ECE", semester: 3, teacher: "Prof. A. Kulkarni", strength: 54 },
  ],
  branches: [
    { id: "b1", code: "CSE", name: "Computer Science", hod: "Dr. S. Menon", classes: 6 },
    { id: "b2", code: "ECE", name: "Electronics", hod: "Dr. P. Shah", classes: 4 },
    { id: "b3", code: "ME", name: "Mechanical", hod: "Dr. V. Iyer", classes: 3 },
  ],
  semesters: [
    { id: "sem1", number: 3, branch: "ECE", students: 54, active: "Yes" },
    { id: "sem2", number: 5, branch: "CSE", students: 120, active: "Yes" },
    { id: "sem3", number: 7, branch: "CSE", students: 112, active: "No" },
  ],
  subjects: [
    { id: "sub1", code: "CS301", name: "Data Structures", branch: "CSE", semester: 5, teacher: "Mr. Anand Verma" },
    { id: "sub2", code: "CS302", name: "DBMS", branch: "CSE", semester: 5, teacher: "Dr. Rita Bose" },
    { id: "sub3", code: "CS303", name: "Operating Systems", branch: "CSE", semester: 5, teacher: "Prof. N. Das" },
    { id: "sub4", code: "MA301", name: "Mathematics III", branch: "CSE", semester: 5, teacher: "Dr. L. Fernandes" },
  ],
};
