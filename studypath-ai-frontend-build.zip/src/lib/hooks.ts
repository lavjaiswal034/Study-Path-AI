import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

gsap.registerPlugin(ScrollTrigger);

export function useReducedMotion() {
  const [reduced, setReduced] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

/* Count-up used on every % / score in the app */
export function useCountUp(target: number, duration = 900) {
  const reduced = useReducedMotion();
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (reduced) {
      setValue(target);
      return;
    }
    let start: number | null = null;
    let raf = 0;
    const tick = (t: number) => {
      if (start === null) start = t;
      const progress = Math.min((t - start) / duration, 1);
      setValue(Math.round(target * progress * 10) / 10);
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, reduced]);
  return value;
}

/* Roadmap path draw-in */
export function usePathDraw(pathRef: React.RefObject<SVGPathElement | null>, trigger: boolean) {
  const reduced = useReducedMotion();
  useEffect(() => {
    const path = pathRef.current;
    if (!path || !trigger) return;
    if (reduced) {
      gsap.set(path, { strokeDasharray: "none", strokeDashoffset: 0 });
      return;
    }
    const length = path.getTotalLength();
    gsap.set(path, { strokeDasharray: length, strokeDashoffset: length });
    gsap.to(path, { strokeDashoffset: 0, duration: 1.4, ease: "power2.inOut" });
  }, [trigger, pathRef, reduced]);
}

/* Smooth scale hover via quickTo — attach to any element */
export function useHoverScale<T extends HTMLElement>(amount = 1.02) {
  const ref = useRef<T | null>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    const el = ref.current;
    if (!el || reduced) return;
    const scale = gsap.quickTo(el, "scale", { duration: 0.25, ease: "power2.out" });
    const enter = () => scale(amount);
    const leave = () => scale(1);
    el.addEventListener("mouseenter", enter);
    el.addEventListener("mouseleave", leave);
    return () => {
      el.removeEventListener("mouseenter", enter);
      el.removeEventListener("mouseleave", leave);
    };
  }, [amount, reduced]);
  return ref;
}

/* Staggered entrance for children matching a selector within scope */
export function useEnterStagger(scope: React.RefObject<HTMLElement | null>, selector: string, deps: unknown[] = []) {
  const reduced = useReducedMotion();
  useGSAP(
    () => {
      if (reduced || !scope.current) return;
      const els = scope.current.querySelectorAll(selector);
      if (!els.length) return;
      gsap.from(els, { y: 22, opacity: 0, duration: 0.55, ease: "power3.out", stagger: 0.07, clearProps: "transform,opacity" });
    },
    { scope, dependencies: deps },
  );
}

/* Scroll-triggered reveal for .reveal-on-scroll elements in scope */
export function useScrollReveal(scope: React.RefObject<HTMLElement | null>, deps: unknown[] = []) {
  const reduced = useReducedMotion();
  useGSAP(
    () => {
      if (reduced || !scope.current) return;
      const els = gsap.utils.toArray<HTMLElement>(".reveal-on-scroll", scope.current);
      els.forEach((el) => {
        gsap.from(el, {
          y: 32,
          opacity: 0,
          duration: 0.7,
          ease: "power2.out",
          clearProps: "transform,opacity",
          scrollTrigger: { trigger: el, start: "top 88%", once: true },
        });
      });
    },
    { scope, dependencies: deps },
  );
}

/* Table rows sliding in */
export function useRowStagger(scope: React.RefObject<HTMLElement | null>, deps: unknown[] = []) {
  const reduced = useReducedMotion();
  useGSAP(
    () => {
      if (reduced || !scope.current) return;
      const rows = scope.current.querySelectorAll(".table-row");
      if (!rows.length) return;
      gsap.from(rows, { opacity: 0, x: -12, duration: 0.4, stagger: 0.04, ease: "power1.out", clearProps: "all" });
    },
    { scope, dependencies: deps },
  );
}
