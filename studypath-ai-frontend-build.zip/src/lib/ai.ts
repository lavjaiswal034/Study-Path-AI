import { FACTOR_KEYS, FACTOR_LABELS } from "../data";
import type { PerformanceFactors, RoadmapDraft } from "../types";

/* ------------------------------------------------------------------ */
/* Rules layer — separate from the ML model, never a confidence score  */
/* ------------------------------------------------------------------ */
export function riskCategory(pct: number): { label: string; tone: "success" | "warning" | "danger" } {
  if (pct >= 75) return { label: "On track", tone: "success" };
  if (pct >= 55) return { label: "Needs attention", tone: "warning" };
  return { label: "At risk", tone: "danger" };
}

export function weakAreas(factors: PerformanceFactors, max = 3) {
  return [...FACTOR_KEYS]
    .map((k) => ({ key: k, label: FACTOR_LABELS[k], value: factors[k] }))
    .sort((a, b) => a.value - b.value)
    .slice(0, max);
}

export function strongAreas(factors: PerformanceFactors, max = 2) {
  return [...FACTOR_KEYS]
    .map((k) => ({ key: k, label: FACTOR_LABELS[k], value: factors[k] }))
    .sort((a, b) => b.value - a.value)
    .slice(0, max);
}

/* Deterministic narrative for the AI Gateway summary card */
export function aiSummary(pct: number, factors: PerformanceFactors): string {
  const weak = weakAreas(factors, 2);
  const strong = strongAreas(factors, 1)[0];
  const risk = riskCategory(pct);
  const lead =
    risk.tone === "success"
      ? `Performance is trending in a healthy band.`
      : risk.tone === "warning"
        ? `Performance is workable but leaves clear marks on the table.`
        : `Performance is below the passing comfort zone and needs immediate structure.`;
  return `${lead} The weakest signals are ${weak.map((w) => `${w.label.toLowerCase()} (${w.value}%)`).join(" and ")}, while ${strong.label.toLowerCase()} (${strong.value}%) is a reliable strength to anchor revision around. A focused plan that front-loads the weak areas and tapers into full-length practice should move the predicted outcome meaningfully.`;
}

/* Per-task review suggestion — always labeled "suggestion only" in UI */
export function aiSuggestion(taskTitle: string, type: string): string {
  switch (type) {
    case "quiz":
      return `For “${taskTitle}”, check answer accuracy on the hardest items first, then verify time taken. Award full marks if ≥80% correct; otherwise return with the specific questions to re-attempt.`;
    case "practice":
      return `For “${taskTitle}”, confirm the implementation runs on the sample cases and that complexity is stated. Code that handles edge cases deserves full credit.`;
    case "assignment":
      return `For “${taskTitle}”, look for complete coverage of the brief and clear explanations. Partial credit is fair if structure is right but details are thin.`;
    default:
      return `For “${taskTitle}”, check that notes cover definitions, operations and complexities. Neat, complete notes merit verification.`;
  }
}

/* ------------------------------------------------------------------ */
/* AI Gateway — roadmap draft generation                               */
/* ------------------------------------------------------------------ */
export const SYSTEM_PROMPT = `
You are an academic roadmap generator for StudyPath AI. Given a student's
ML-predicted performance, weak areas, and available study time, produce a
day-by-day roadmap as STRICT JSON matching this shape:

{
  "priorityFocus": string,
  "days": [
    { "dayNumber": number, "title": string, "tasks": [
      { "title": string, "type": "study"|"quiz"|"assignment"|"practice",
        "estimatedMinutes": number, "priority": "low"|"medium"|"high" }
    ]}
  ]
}

Rules:
- Output ONLY valid JSON. No prose, no markdown fences.
- Never mention or infer a confidence score.
- Keep each day's total time within the student's stated available time.
- Front-load tasks on the stated weak areas, taper to review in the final days.
- Never reference internal model or feature names.
`;

interface GenInput {
  studentName: string;
  subject: string;
  days: number;
  minutesPerDay: number;
  weak: { label: string; value: number }[];
  apiKey?: string;
}

export interface GeneratedDay {
  dayNumber: number;
  title: string;
  tasks: { title: string; type: "study" | "quiz" | "assignment" | "practice"; estimatedMinutes: number; priority: "low" | "medium" | "high" }[];
}

const TOPICS = [
  "Arrays & Linked Lists", "Stacks & Queues", "Recursion & Trees", "Graph Traversals",
  "Hashing", "Heaps & Priority Queues", "Sorting & Searching", "Revision & Mock Test",
];

function mockGenerate(input: GenInput): { priorityFocus: string; days: GeneratedDay[] } {
  const focus = input.weak.map((w) => w.label).join(" · ") || "Balanced revision";
  const days: GeneratedDay[] = [];
  for (let i = 0; i < input.days; i++) {
    const taper = i >= input.days - 2;
    const topic = TOPICS[i % TOPICS.length];
    const tasks: GeneratedDay["tasks"] = [];
    let remaining = input.minutesPerDay;
    const weakLabel = input.weak[i % Math.max(1, input.weak.length)]?.label ?? "core topics";
    tasks.push({
      title: taper ? `Review ${topic}` : `${topic} — concept pass`,
      type: taper ? "study" : "study",
      estimatedMinutes: Math.min(remaining, taper ? 25 : 30),
      priority: taper ? "medium" : "high",
    });
    remaining -= tasks[0].estimatedMinutes;
    if (remaining >= 20) {
      tasks.push({
        title: taper ? "Full-length timed mock" : `Timed drill — ${weakLabel.toLowerCase()}`,
        type: taper ? "quiz" : i % 2 === 0 ? "quiz" : "practice",
        estimatedMinutes: Math.min(remaining, 30),
        priority: taper ? "high" : "high",
      });
      remaining -= tasks[1].estimatedMinutes;
    }
    if (remaining >= 15 && !taper) {
      tasks.push({ title: `Write-up: ${topic} summary`, type: "assignment", estimatedMinutes: Math.min(remaining, 20), priority: "low" });
    }
    days.push({ dayNumber: i + 1, title: taper ? (i === input.days - 1 ? "Mock & Final Revision" : "Consolidation") : topic, tasks });
  }
  return { priorityFocus: focus, days };
}

export async function generateRoadmapDraft(input: GenInput): Promise<{ priorityFocus: string; days: GeneratedDay[]; fellBack: boolean }> {
  // Small artificial latency so the generation sequence reads clearly.
  await new Promise((r) => setTimeout(r, 1400));

  if (input.apiKey && input.apiKey.trim().length > 8) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${input.apiKey.trim()}` },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            {
              role: "user",
              content: `Student: ${input.studentName}. Subject: ${input.subject}. Days: ${input.days}. Available minutes per day: ${input.minutesPerDay}. Weak areas: ${input.weak.map((w) => `${w.label} ${w.value}%`).join(", ")}.`,
            },
          ],
          temperature: 0.4,
        }),
      });
      if (!res.ok) throw new Error(`Gateway responded ${res.status}`);
      const json = await res.json();
      const raw: string = json?.choices?.[0]?.message?.content ?? "";
      const cleaned = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (!parsed?.days?.length || !Array.isArray(parsed.days)) throw new Error("Unexpected shape");
      return { priorityFocus: parsed.priorityFocus ?? input.weak.map((w) => w.label).join(" · "), days: parsed.days, fellBack: false };
    } catch {
      // Defensive: invalid JSON / network failure → actionable fallback, never a crash.
      return { ...mockGenerate(input), fellBack: true };
    }
  }
  return { ...mockGenerate(input), fellBack: false };
}

export function toRoadmapDraft(
  gen: { priorityFocus: string; days: GeneratedDay[] },
  meta: { id: string; studentId: string; subject: string; predictionId: string; source: RoadmapDraft["source"] },
): RoadmapDraft {
  return {
    id: meta.id,
    studentId: meta.studentId,
    subject: meta.subject,
    predictionId: meta.predictionId,
    priorityFocus: gen.priorityFocus,
    durationDays: gen.days.length,
    status: "draft",
    source: meta.source,
    createdAt: new Date().toISOString(),
    days: gen.days.map((d, i) => ({
      id: `${meta.id}_d${i + 1}`,
      dayNumber: d.dayNumber ?? i + 1,
      title: d.title,
      tasks: (d.tasks ?? []).map((t, j) => ({
        id: `${meta.id}_t${i + 1}_${j + 1}`,
        title: t.title,
        subject: meta.subject,
        type: t.type,
        priority: t.priority,
        estimatedMinutes: t.estimatedMinutes,
        assignTo: { scope: "student", ids: [meta.studentId] },
        status: "not_started" as const,
      })),
    })),
  };
}
