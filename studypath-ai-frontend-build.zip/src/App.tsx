import { Bell, CheckCheck } from "lucide-react";
import { useRef } from "react";
import Shell from "./components/Shell";
import { Card, SectionHead, cn } from "./components/ui";
import { notifications } from "./data";
import { useRowStagger } from "./lib/hooks";
import Login from "./pages/Login";
import { AdminAnalytics, AdminDashboard, AdminReports, AdminSettings } from "./pages/admin/Core";
import { AdminBranches, AdminClasses, AdminSemesters, AdminStudents, AdminSubjects, AdminTeachers, AdminUsers } from "./pages/admin/Entities";
import StudentDashboard from "./pages/student/Dashboard";
import StudentMisc from "./pages/student/Misc";
import StudentPredictions from "./pages/student/Predictions";
import StudentRoadmap from "./pages/student/Roadmap";
import StudentTasks from "./pages/student/Tasks";
import { TeacherAnalytics, TeacherPredictions, TeacherReports } from "./pages/teacher/Analytics";
import TeacherDashboard from "./pages/teacher/Dashboard";
import TeacherRoadmaps from "./pages/teacher/Roadmaps";
import { TeacherPerformance, TeacherStudents, TeacherSubjects } from "./pages/teacher/Students";
import TeacherVerification from "./pages/teacher/Verification";
import { useApp, useAuth } from "./store";
import type { Role } from "./types";

function TeacherNotifications() {
  const role = useAuth((s) => s.role)!;
  const readNotifs = useApp((s) => s.readNotifs);
  const markRead = useApp((s) => s.markNotifRead);
  const mine = notifications.filter((n) => n.audience === role);
  const ref = useRef<HTMLDivElement>(null);
  useRowStagger(ref, []);
  return (
    <div>
      <SectionHead title="Notifications" desc="Alerts for your scope." right={
        <button className="btn btn-secondary btn-sm" onClick={() => mine.forEach((n) => markRead(n.id))}><CheckCheck size={13} /> Mark all read</button>
      } />
      <div ref={ref} className="space-y-2.5 max-w-3xl">
        {mine.length === 0 && <Card className="p-8 text-center text-[13px] text-[var(--text-muted)]">You're all caught up.</Card>}
        {mine.map((n) => {
          const read = readNotifs.includes(n.id);
          return (
            <button key={n.id} onClick={() => markRead(n.id)} className={cn("table-row w-full text-left card p-4 flex items-start gap-3", !read && "border-l-4 border-l-[var(--accent)]")}>
              <span className={cn("w-9 h-9 rounded-[10px] grid place-items-center shrink-0",
                n.kind === "success" ? "bg-[var(--success-soft)] text-[var(--success)]" : n.kind === "warning" ? "bg-[var(--warning-soft)] text-[var(--warning)]" : n.kind === "danger" ? "bg-[var(--danger-soft)] text-[var(--danger)]" : "bg-[var(--accent-soft)] text-[var(--accent)]")}>
                <Bell size={16} />
              </span>
              <span className="flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="text-[13.5px] font-semibold">{n.title}</span>
                  <span className="text-[11px] text-[var(--text-muted)]">{n.time}</span>
                </span>
                <span className="block text-[12.5px] text-[var(--text-muted)] mt-0.5">{n.body}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function renderPage(role: Role, page: string) {
  if (role === "student") {
    switch (page) {
      case "dashboard": return <StudentDashboard />;
      case "predictions": return <StudentPredictions />;
      case "roadmap": return <StudentRoadmap />;
      case "tasks": return <StudentTasks />;
      default: return <StudentMisc page={page} />;
    }
  }
  if (role === "class_teacher" || role === "subject_teacher") {
    switch (page) {
      case "students": return <TeacherStudents />;
      case "subjects": return <TeacherSubjects />;
      case "performance": return <TeacherPerformance />;
      case "predictions": return <TeacherPredictions />;
      case "roadmaps": case "tasks": return <TeacherRoadmaps />;
      case "verification": return <TeacherVerification />;
      case "analytics": return <TeacherAnalytics />;
      case "reports": return <TeacherReports />;
      case "notifications": return <TeacherNotifications />;
      default: return <TeacherDashboard />;
    }
  }
  switch (page) {
    case "users": return <AdminUsers />;
    case "students": return <AdminStudents />;
    case "teachers": return <AdminTeachers />;
    case "classes": return <AdminClasses />;
    case "branches": return <AdminBranches />;
    case "semesters": return <AdminSemesters />;
    case "subjects": return <AdminSubjects />;
    case "analytics": return <AdminAnalytics />;
    case "reports": return <AdminReports />;
    case "settings": return <AdminSettings />;
    default: return <AdminDashboard />;
  }
}

export default function App() {
  const role = useAuth((s) => s.role);
  const page = useApp((s) => s.page);
  if (!role) return <Login />;
  return <Shell>{renderPage(role, page)}</Shell>;
}
