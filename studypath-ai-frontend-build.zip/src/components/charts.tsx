import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useRef, type ReactNode } from "react";
import { useReducedMotion } from "../lib/hooks";

const ACCENT = "#2563EB";
const MUTED = "#9AA1AC";

function ChartCard({ children, title, sub, right, className }: { children: ReactNode; title?: string; sub?: string; right?: ReactNode; className?: string }) {
  const scope = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  useGSAP(
    () => {
      if (reduced || !scope.current) return;
      gsap.from(scope.current, { opacity: 0, scale: 0.97, y: 14, duration: 0.6, ease: "power3.out", clearProps: "all" });
    },
    { scope },
  );
  return (
    <div ref={scope} className={`card p-5 ${className ?? ""}`}>
      {(title || right) && (
        <div className="flex items-start justify-between mb-4">
          <div>
            {title && <h3 className="font-display text-[15px] font-semibold">{title}</h3>}
            {sub && <p className="text-[12px] text-[var(--text-muted)] mt-0.5">{sub}</p>}
          </div>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

const tooltipStyle = {
  borderRadius: 10, border: "1px solid var(--border)", boxShadow: "var(--shadow-pop)",
  fontSize: 12, padding: "8px 12px",
};

export function TrendChart({ data, height = 220 }: { data: { label: string; pct: number; status: string }[]; height?: number }) {
  return (
    <ChartCard title="Prediction trend" sub="Model E46_V1 · append-only history">
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#EEF0F4" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
          <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v}%`, "Predicted"]} />
          <Line type="monotone" dataKey="pct" stroke={ACCENT} strokeWidth={2.5} dot={{ r: 3.5, fill: ACCENT, strokeWidth: 2, stroke: "#fff" }} activeDot={{ r: 5 }} />
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function FactorBars({ data, height = 220, color = ACCENT }: { data: { label: string; value: number }[]; height?: number; color?: string }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout="vertical" margin={{ top: 0, right: 24, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="#EEF0F4" horizontal={false} />
        <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
        <YAxis type="category" dataKey="label" width={128} tick={{ fontSize: 11.5, fill: "#3F4550" }} axisLine={false} tickLine={false} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v}%`, "Score"]} cursor={{ fill: "rgba(37,99,235,0.05)" }} />
        <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={14}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.value < 60 ? "#D97706" : color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function FactorBarCard({ data, title, sub }: { data: { label: string; value: number }[]; title: string; sub?: string }) {
  return (
    <ChartCard title={title} sub={sub}>
      <FactorBars data={data} />
    </ChartCard>
  );
}

export function DistributionChart({ data, height = 220 }: { data: { label: string; count: number; color: string }[]; height?: number }) {
  return (
    <ChartCard title="Predicted outcome distribution" sub="Students per risk band">
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
          <CartesianGrid stroke="#EEF0F4" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11.5, fill: MUTED }} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v}`, "Students"]} cursor={{ fill: "rgba(37,99,235,0.05)" }} />
          <Bar dataKey="count" radius={[6, 6, 0, 0]} barSize={44}>
            {data.map((d, i) => (
              <Cell key={i} fill={d.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export function ActivityChart({ data, height = 200 }: { data: { label: string; verified: number; submitted: number }[]; height?: number }) {
  return (
    <ChartCard title="Verification activity" sub="Tasks verified vs awaiting, last 7 days">
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
          <CartesianGrid stroke="#EEF0F4" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: MUTED }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(37,99,235,0.05)" }} />
          <Bar dataKey="verified" stackId="a" fill={ACCENT} radius={[0, 0, 0, 0]} barSize={22} />
          <Bar dataKey="submitted" stackId="a" fill="#C7D4F6" radius={[6, 6, 0, 0]} barSize={22} />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

export { ChartCard };
