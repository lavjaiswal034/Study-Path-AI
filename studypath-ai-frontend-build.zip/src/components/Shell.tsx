import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import {
  BarChart3, Bell, BookOpen, Brain, ClipboardList, FileText, GraduationCap, Layers,
  LayoutDashboard, Library, LogOut, Menu, Network, Route, School, Settings, ShieldCheck,
  TrendingUp, User, UserCog, Users, X, type LucideIcon,
} from "lucide-react";
import { useMemo, useRef, useState, type ReactNode } from "react";
import { notifications } from "../data";
import { useReducedMotion } from "../lib/hooks";
import { useApp, useAuth } from "../store";
import type { Role } from "../types";
import { Avatar, cn } from "./ui";

interface NavItem { key: string; label: string; icon: LucideIcon }

const NAV: Record<Role, NavItem[]> = {
  student: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "subjects", label: "My Subjects", icon: BookOpen },
    { key: "performance", label: "Performance", icon: TrendingUp },
    { key: "predictions", label: "Predictions", icon: Brain },
    { key: "roadmap", label: "AI Roadmap", icon: Route },
    { key: "tasks", label: "Tasks", icon: ClipboardList },
    { key: "resources", label: "Learning Resources", icon: Library },
    { key: "analytics", label: "Analytics", icon: BarChart3 },
    { key: "notifications", label: "Notifications", icon: Bell },
    { key: "profile", label: "Profile", icon: User },
    { key: "settings", label: "Settings", icon: Settings },
  ],
  class_teacher: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "students", label: "Students", icon: Users },
    { key: "subjects", label: "Subjects", icon: BookOpen },
    { key: "performance", label: "Performance", icon: TrendingUp },
    { key: "predictions", label: "Predictions", icon: Brain },
    { key: "roadmaps", label: "Roadmaps", icon: Route },
    { key: "verification", label: "Verification", icon: ShieldCheck },
    { key: "analytics", label: "Analytics", icon: BarChart3 },
    { key: "reports", label: "Reports", icon: FileText },
    { key: "notifications", label: "Notifications", icon: Bell },
  ],
  subject_teacher: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "subjects", label: "My Subjects", icon: BookOpen },
    { key: "students", label: "Students", icon: Users },
    { key: "performance", label: "Performance", icon: TrendingUp },
    { key: "predictions", label: "Predictions", icon: Brain },
    { key: "roadmaps", label: "Roadmaps", icon: Route },
    { key: "tasks", label: "Task Management", icon: ClipboardList },
    { key: "verification", label: "Verification", icon: ShieldCheck },
    { key: "analytics", label: "Analytics", icon: BarChart3 },
    { key: "reports", label: "Reports", icon: FileText },
  ],
  admin: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "users", label: "Users", icon: UserCog },
    { key: "students", label: "Students", icon: GraduationCap },
    { key: "teachers", label: "Teachers", icon: User },
    { key: "classes", label: "Classes", icon: School },
    { key: "branches", label: "Branches", icon: Network },
    { key: "semesters", label: "Semesters", icon: Layers },
    { key: "subjects", label: "Subjects", icon: BookOpen },
    { key: "analytics", label: "Prediction Analytics", icon: BarChart3 },
    { key: "reports", label: "Reports", icon: FileText },
    { key: "settings", label: "Settings", icon: Settings },
  ],
};

const ROLE_NAME: Record<Role, string> = {
  student: "Rahul Kumar",
  class_teacher: "Ms. Kavita Rao",
  subject_teacher: "Mr. Anand Verma",
  admin: "Dr. S. Menon",
};

const ROLE_COLOR: Record<Role, string> = {
  student: "#2563EB", class_teacher: "#16A34A", subject_teacher: "#D97706", admin: "#111318",
};

function Brand() {
  return (
    <div className="flex items-center gap-2.5 px-2">
      <span className="w-8 h-8 rounded-[9px] bg-[var(--primary)] grid place-items-center shrink-0">
        <svg width="18" height="18" viewBox="0 0 32 32" fill="none" aria-hidden="true">
          <path d="M9 23c0-7 4-12 7-12s7 5 7 12" stroke="#2563EB" strokeWidth="2.6" strokeLinecap="round" />
          <circle cx="16" cy="10" r="2.6" fill="#fff" />
        </svg>
      </span>
      <div className="leading-tight">
        <div className="font-display font-semibold text-[15px]">StudyPath AI</div>
        <div className="text-[10.5px] text-[var(--text-muted)] font-medium tracking-wide">PREDICT · PLAN · VERIFY</div>
      </div>
    </div>
  );
}

export default function Shell({ children }: { children: ReactNode }) {
  const role = useAuth((s) => s.role)!;
  const logout = useAuth((s) => s.logout);
  const page = useApp((s) => s.page);
  const navigate = useApp((s) => s.navigate);
  const readNotifs = useApp((s) => s.readNotifs);
  const [mobileOpen, setMobileOpen] = useState(false);
  const reduced = useReducedMotion();

  const nav = NAV[role];
  const active = nav.find((n) => n.key === page) ?? nav[0];
  const myNotifs = notifications.filter((n) => n.audience === role);
  const unread = myNotifs.filter((n) => !readNotifs.includes(n.id)).length;

  const go = (key: string) => {
    navigate(key);
    setMobileOpen(false);
  };

  const sidebarRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  /* sliding active indicator */
  useGSAP(
    () => {
      const root = sidebarRef.current;
      if (!root) return;
      const el = root.querySelector<HTMLElement>(".nav-item.active");
      const ind = root.querySelector<HTMLElement>(".nav-indicator");
      if (!el || !ind) return;
      if (reduced) {
        gsap.set(ind, { top: el.offsetTop + 6, height: el.offsetHeight - 12, opacity: 1 });
        return;
      }
      gsap.to(ind, { top: el.offsetTop + 6, height: el.offsetHeight - 12, opacity: 1, duration: 0.35, ease: "power3.inOut" });
    },
    { scope: sidebarRef, dependencies: [page, role, mobileOpen] },
  );

  /* page transition on route change */
  useGSAP(
    () => {
      if (reduced || !contentRef.current) return;
      gsap.fromTo(contentRef.current, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.3, ease: "power2.out", clearProps: "all" });
    },
    { scope: contentRef, dependencies: [page] },
  );

  const sidebar = useMemo(
    () => (
      <div className="flex flex-col h-full">
        <div className="h-16 flex items-center px-3 border-b border-[var(--border)]">
          <Brand />
        </div>
        <nav className="relative flex-1 overflow-y-auto scroll-thin px-3 py-4 space-y-0.5" aria-label="Primary">
          <span className="nav-indicator" style={{ opacity: 0 }} aria-hidden="true" />
          {nav.map((n) => (
            <button key={n.key} className={cn("nav-item", page === n.key && "active")} onClick={() => go(n.key)} aria-current={page === n.key ? "page" : undefined}>
              <n.icon size={17} strokeWidth={2} className="shrink-0" />
              <span className="truncate">{n.label}</span>
              {n.key === "notifications" && unread > 0 && (
                <span className="ml-auto min-w-[18px] h-[18px] px-1 rounded-full bg-[var(--danger)] text-white text-[10.5px] font-bold grid place-items-center">{unread}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-[var(--border)]">
          <div className="flex items-center gap-2.5 p-2 rounded-xl bg-[#f4f6f9]">
            <Avatar name={ROLE_NAME[role]} color={ROLE_COLOR[role]} size={32} />
            <div className="min-w-0 flex-1">
              <div className="text-[12.5px] font-semibold truncate">{ROLE_NAME[role]}</div>
              <div className="text-[11px] text-[var(--text-muted)] capitalize">{role.replace("_", " ")}</div>
            </div>
            <button className="btn btn-ghost btn-icon" onClick={logout} aria-label="Sign out"><LogOut size={15} /></button>
          </div>
        </div>
      </div>
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [nav, page, role, unread],
  );

  return (
    <div className="min-h-screen flex">
      {/* desktop sidebar */}
      <aside ref={sidebarRef} className="hidden lg:flex w-[260px] shrink-0 flex-col bg-[var(--surface)] border-r border-[var(--border)] fixed inset-y-0 left-0 z-30">
        {sidebar}
      </aside>

      {/* mobile off-canvas */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-[rgba(17,19,24,0.4)]" onClick={() => setMobileOpen(false)} />
          <aside ref={undefined} className="absolute inset-y-0 left-0 w-[280px] bg-[var(--surface)] shadow-2xl flex flex-col">
            <div className="absolute top-4 right-3 z-10">
              <button className="btn btn-ghost btn-icon" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X size={18} /></button>
            </div>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="flex-1 lg:ml-[260px] min-w-0 flex flex-col">
        <header className="h-16 sticky top-0 z-20 bg-[rgba(247,248,250,0.85)] backdrop-blur border-b border-[var(--border)] flex items-center gap-3 px-4 sm:px-6">
          <button className="btn btn-ghost btn-icon lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={19} /></button>
          <div className="min-w-0">
            <div className="text-[11px] text-[var(--text-muted)] font-medium capitalize">{role.replace("_", " ")}</div>
            <h2 className="font-display text-[15.5px] font-semibold leading-tight truncate">{active.label}</h2>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button
              className="btn btn-ghost btn-icon relative"
              onClick={() => go("notifications")}
              aria-label={`Notifications, ${unread} unread`}
            >
              <Bell size={18} />
              {unread > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[var(--danger)]" />}
            </button>
            <Avatar name={ROLE_NAME[role]} color={ROLE_COLOR[role]} size={32} />
          </div>
        </header>

        <main ref={contentRef} className="flex-1 p-4 sm:p-6 max-w-[1280px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export { NAV, ROLE_NAME };
