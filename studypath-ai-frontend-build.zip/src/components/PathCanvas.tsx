import gsap from "gsap";
import { Check, Lock } from "lucide-react";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { usePathDraw, useReducedMotion } from "../lib/hooks";
import type { RoadmapDay } from "../types";
import { cn } from "./ui";

const SPACING = 168;
const TOP = 64;
const W = 400;

function buildPath(count: number) {
  if (count <= 1) return `M 200 ${TOP} L 200 ${TOP + 40}`;
  let d = `M 200 ${TOP}`;
  for (let i = 1; i < count; i++) {
    const prevY = TOP + (i - 1) * SPACING;
    const y = TOP + i * SPACING;
    const l = i % 2 === 1 ? 64 : 336;
    const r = i % 2 === 1 ? 336 : 64;
    d += ` C ${l} ${prevY + 60}, ${r} ${y - 60}, 200 ${y}`;
  }
  return d;
}

export function dayState(day: RoadmapDay): "completed" | "active" | "locked" {
  if (day.tasks.length === 0) return "locked";
  if (day.tasks.every((t) => t.status === "verified")) return "completed";
  if (day.tasks.some((t) => t.status === "submitted" || t.status === "verified" || t.status === "needs_revision")) return "active";
  return "locked";
}

export default function PathCanvas({
  days, selectedIndex, onSelect, studentInitial,
}: {
  days: RoadmapDay[];
  selectedIndex: number;
  onSelect: (i: number) => void;
  studentInitial: string;
}) {
  const pathRef = useRef<SVGPathElement>(null);
  const progressRef = useRef<SVGPathElement>(null);
  const reduced = useReducedMotion();
  const [points, setPoints] = useState<{ x: number; y: number }[]>([]);

  const d = useMemo(() => buildPath(days.length), [days.length]);
  const H = TOP * 2 + (days.length - 1) * SPACING;

  usePathDraw(pathRef, true);

  /* place nodes exactly on the curve */
  useLayoutEffect(() => {
    const path = pathRef.current;
    if (!path) return;
    const len = path.getTotalLength();
    const pts = days.map((_, i) => {
      const dist = days.length === 1 ? 0 : (len / (days.length - 1)) * i;
      return path.getPointAtLength(dist);
    });
    setPoints(pts);

    /* progress overlay up to the selected (current) node */
    const prog = progressRef.current;
    if (prog) {
      const target = days.length === 1 ? 0 : (len / (days.length - 1)) * selectedIndex;
      if (reduced) {
        gsap.set(prog, { strokeDasharray: len, strokeDashoffset: len - target });
      } else {
        gsap.set(prog, { strokeDasharray: len, strokeDashoffset: len });
        gsap.to(prog, { strokeDashoffset: len - target, duration: 1.6, ease: "power2.inOut", delay: 0.2 });
      }
    }
  }, [days, selectedIndex, reduced, d]);

  return (
    <div className="relative mx-auto w-full max-w-[420px]" style={{ height: H }}>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="absolute inset-0 w-full h-full" aria-hidden="true">
        <path ref={pathRef} d={d} fill="none" stroke="#E7E9EE" strokeWidth={10} strokeLinecap="round" />
        <path ref={progressRef} d={d} fill="none" stroke="url(#pathGrad)" strokeWidth={10} strokeLinecap="round" />
        <defs>
          <linearGradient id="pathGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7C3AED" />
            <stop offset="100%" stopColor="#2563EB" />
          </linearGradient>
        </defs>
      </svg>

      {points.map((p, i) => {
        const day = days[i];
        const state = dayState(day);
        const isSelected = i === selectedIndex;
        const done = day.tasks.filter((t) => t.status === "verified").length;
        return (
          <div
            key={day.id}
            className="absolute"
            style={{ left: `${(p.x / W) * 100}%`, top: `${(p.y / H) * 100}%`, transform: "translate(-50%,-50%)" }}
          >
            <div className={cn("relative flex items-center", i % 2 === 0 ? "flex-row" : "flex-row-reverse")}>
              <button
                onClick={() => onSelect(i)}
                aria-label={`Day ${day.dayNumber}: ${day.title}`}
                className={cn(
                  "relative z-10 w-12 h-12 rounded-full grid place-items-center border-2 transition-transform",
                  state === "completed" && "bg-[var(--success)] border-[var(--success)] text-white",
                  state === "active" && "bg-white border-[var(--path-purple)] text-[var(--path-purple)] node-active",
                  state === "locked" && "bg-[#EEF0F4] border-[#DDE1E8] text-[var(--text-muted)]",
                  isSelected && "ring-4 ring-[rgba(124,58,237,0.18)]",
                )}
              >
                {state === "completed" ? <Check size={19} strokeWidth={3} /> : state === "locked" ? <Lock size={15} /> : <span className="font-display font-bold text-[15px]">{day.dayNumber}</span>}
              </button>

              <button
                onClick={() => onSelect(i)}
                className={cn(
                  "mx-3 text-left w-44 shrink-0",
                )}
              >
                <span className={cn("block text-[11px] font-bold tracking-wide uppercase", state === "locked" ? "text-[#A6ACB8]" : "text-[var(--path-purple)]")}>
                  Day {day.dayNumber}
                </span>
                <span className={cn("block text-[13px] font-semibold leading-snug", state === "locked" ? "text-[var(--text-muted)]" : "text-[var(--text-primary)]")}>
                  {day.title}
                </span>
                <span className="block text-[11.5px] text-[var(--text-muted)] mt-0.5">
                  {done}/{day.tasks.length} tasks verified
                </span>
              </button>

              {/* avatar on the active day */}
              {state === "active" && (
                <span
                  className="absolute z-20 w-7 h-7 rounded-full bg-[var(--primary)] text-white text-[11px] font-bold grid place-items-center border-2 border-white shadow-md"
                  style={{ top: -18, left: i % 2 === 0 ? -6 : undefined, right: i % 2 !== 0 ? -6 : undefined, animation: reduced ? undefined : "floaty 2.4s ease-in-out infinite" }}
                  aria-hidden="true"
                >
                  {studentInitial}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
