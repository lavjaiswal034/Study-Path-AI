import { AnimatePresence, motion } from "framer-motion";
import { BookOpen, FileText, FlaskConical, ListChecks, X, type LucideIcon } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { useCountUp, useHoverScale } from "../lib/hooks";
import type { TaskPriority, TaskStatus, TaskType } from "../types";

export const cn = (...c: (string | false | undefined | null)[]) => c.filter(Boolean).join(" ");

/* ---------------- status metadata ---------------- */
export const TASK_STATUS: Record<TaskStatus, { label: string; tone: string }> = {
  not_started: { label: "Not started", tone: "muted" },
  submitted: { label: "Submitted", tone: "accent" },
  verified: { label: "Verified", tone: "success" },
  needs_revision: { label: "Needs revision", tone: "warning" },
};

export const PRIORITY: Record<TaskPriority, { label: string; tone: string }> = {
  high: { label: "High", tone: "danger" },
  medium: { label: "Medium", tone: "warning" },
  low: { label: "Low", tone: "muted" },
};

export const TYPE_META: Record<TaskType, { label: string; icon: LucideIcon }> = {
  study: { label: "Study", icon: BookOpen },
  quiz: { label: "Quiz", icon: ListChecks },
  assignment: { label: "Assignment", icon: FileText },
  practice: { label: "Practice", icon: FlaskConical },
};

/* ---------------- primitives ---------------- */
export function Card({ children, className, hover, onClick }: { children: ReactNode; className?: string; hover?: boolean; onClick?: () => void }) {
  const ref = useHoverScale<HTMLDivElement>(1.012);
  return (
    <div ref={hover ? ref : undefined} onClick={onClick} className={cn("card", hover && "card-hover", onClick && "cursor-pointer", className)}>
      {children}
    </div>
  );
}

export function Pill({ tone = "muted", children, className }: { tone?: string; children: ReactNode; className?: string }) {
  return <span className={cn("pill", `pill-${tone}`, className)}>{children}</span>;
}

export function SectionHead({ title, desc, right }: { title: string; desc?: string; right?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 mb-5">
      <div>
        <h1 className="font-display text-[26px] font-semibold leading-8 text-[var(--text-primary)]">{title}</h1>
        {desc && <p className="text-[13px] text-[var(--text-muted)] mt-1 max-w-xl">{desc}</p>}
      </div>
      {right && <div className="flex items-center gap-2">{right}</div>}
    </div>
  );
}

export function StatCard({
  icon: Icon, label, value, suffix = "", decimals = 0, sub, tone = "accent",
}: {
  icon: LucideIcon; label: string; value: number; suffix?: string; decimals?: number; sub?: ReactNode; tone?: string;
}) {
  const v = useCountUp(value);
  const toneColor: Record<string, string> = {
    accent: "text-[var(--accent)] bg-[var(--accent-soft)]",
    success: "text-[var(--success)] bg-[var(--success-soft)]",
    warning: "text-[var(--warning)] bg-[var(--warning-soft)]",
    danger: "text-[var(--danger)] bg-[var(--danger-soft)]",
    purple: "text-[var(--path-purple)] bg-[var(--purple-soft)]",
    dark: "text-white bg-[var(--primary)]",
  };
  return (
    <Card hover className="stat-card p-4">
      <div className="flex items-start justify-between">
        <span className={cn("w-9 h-9 rounded-[10px] grid place-items-center", toneColor[tone] ?? toneColor.accent)}>
          <Icon size={17} strokeWidth={2.2} />
        </span>
      </div>
      <div className="mt-3 font-display text-[26px] font-semibold leading-none tabular-nums">
        {v.toFixed(decimals)}
        <span className="text-[15px] font-medium text-[var(--text-muted)] ml-0.5">{suffix}</span>
      </div>
      <div className="mt-1.5 text-[12.5px] font-medium text-[var(--text-muted)]">{label}</div>
      {sub && <div className="mt-1 text-[12px] text-[var(--text-muted)]">{sub}</div>}
    </Card>
  );
}

export function ProgressBar({ value, tone = "accent", className }: { value: number; tone?: string; className?: string }) {
  const colors: Record<string, string> = {
    accent: "bg-[var(--accent)]", success: "bg-[var(--success)]", warning: "bg-[var(--warning)]",
    danger: "bg-[var(--danger)]", purple: "bg-[var(--path-purple)]", dark: "bg-[var(--primary)]",
  };
  return (
    <div className={cn("h-1.5 rounded-full bg-[#eef0f4] overflow-hidden", className)}>
      <div className={cn("h-full rounded-full transition-[width] duration-700", colors[tone] ?? colors.accent)} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

export function Avatar({ name, color, size = 34 }: { name: string; color?: string; size?: number }) {
  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("");
  return (
    <span
      className="rounded-full grid place-items-center font-semibold text-white shrink-0"
      style={{ width: size, height: size, background: color ?? "#2563EB", fontSize: size * 0.38 }}
      aria-label={name}
    >
      {initials}
    </span>
  );
}

/* ---------------- form fields ---------------- */
export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint && <p className="text-[11.5px] text-[var(--text-muted)] mt-1">{hint}</p>}
    </div>
  );
}

/* ---------------- tabs ---------------- */
export function Tabs({ items, active, onChange }: { items: { key: string; label: string; count?: number }[]; active: string; onChange: (k: string) => void }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto scroll-thin border-b border-[var(--border)] mb-5">
      {items.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={cn(
            "px-3.5 py-2.5 text-[13px] font-semibold whitespace-nowrap border-b-2 -mb-px transition-colors",
            active === t.key ? "border-[var(--accent)] text-[var(--text-primary)]" : "border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]",
          )}
        >
          {t.label}
          {typeof t.count === "number" && (
            <span className={cn("ml-1.5 px-1.5 py-0.5 rounded-full text-[10.5px]", active === t.key ? "bg-[var(--accent-soft)] text-[var(--accent)]" : "bg-[#f0f1f4] text-[var(--text-muted)]")}>
              {t.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

/* ---------------- modal ---------------- */
export function Modal({ open, onClose, title, children, wide, footer }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; wide?: boolean; footer?: ReactNode }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-center p-4 bg-[rgba(17,19,24,0.38)] backdrop-blur-[2px]"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            className={cn("card w-full max-h-[88vh] flex flex-col", wide ? "max-w-3xl" : "max-w-lg")}
            initial={{ opacity: 0, scale: 0.94, y: 14 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            role="dialog" aria-modal="true"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border)]">
              <h3 className="font-display text-[16px] font-semibold">{title}</h3>
              <button className="btn btn-ghost btn-icon" onClick={onClose} aria-label="Close dialog"><X size={17} /></button>
            </div>
            <div className="p-5 overflow-y-auto scroll-thin">{children}</div>
            {footer && <div className="px-5 py-4 border-t border-[var(--border)] flex items-center justify-end gap-2">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------------- empty state ---------------- */
export function EmptyState({ icon: Icon, title, desc, action }: { icon: LucideIcon; title: string; desc: string; action?: ReactNode }) {
  return (
    <div className="card p-10 flex flex-col items-center text-center">
      <span className="w-12 h-12 rounded-2xl bg-[#f0f2f6] grid place-items-center text-[var(--text-muted)] mb-4">
        <Icon size={22} />
      </span>
      <h3 className="font-display text-[16px] font-semibold">{title}</h3>
      <p className="text-[13px] text-[var(--text-muted)] mt-1.5 max-w-sm">{desc}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function SkeletonRows({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-3 p-4">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton h-9 w-full" />
      ))}
    </div>
  );
}
