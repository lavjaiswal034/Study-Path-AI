import { create } from "zustand";
import { persist } from "zustand/middleware";
import { seedRoadmaps, seedSubmissions } from "./data";
import type { RoadmapDraft, RoadmapTask, Role, Student, TaskStatus } from "./types";

/* ------------------------------------------------------------------ */
/* Auth — card-click for now, AuthProvider-shaped for a real backend   */
/* ------------------------------------------------------------------ */
interface AuthState {
  role: Role | null;
  login: (role: Role) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      role: null,
      login: (role) => set({ role }),
      logout: () => set({ role: null }),
    }),
    { name: "studypath-auth" },
  ),
);

/* Concrete teacher permission model — every teacher screen checks this */
export interface Permissions {
  scopeStudents: (s: Student) => boolean;
  scopeSubject: (subject: string) => boolean;
  verifyAny: boolean;
  createClasswide: boolean;
  label: string;
}

export function permissions(role: Role | null): Permissions {
  switch (role) {
    case "class_teacher":
      return {
        scopeStudents: (s) => s.className === "CSE-3A",
        scopeSubject: () => true,
        verifyAny: true,
        createClasswide: true,
        label: "Class Teacher · CSE-3A",
      };
    case "subject_teacher":
      return {
        scopeStudents: () => true,
        scopeSubject: (subject) => subject === "Data Structures",
        verifyAny: false,
        createClasswide: false,
        label: "Subject Teacher · Data Structures",
      };
    case "admin":
      return {
        scopeStudents: () => true,
        scopeSubject: () => true,
        verifyAny: true,
        createClasswide: true,
        label: "Administrator",
      };
    default:
      return {
        scopeStudents: () => false,
        scopeSubject: () => false,
        verifyAny: false,
        createClasswide: false,
        label: "Guest",
      };
  }
}

/* ------------------------------------------------------------------ */
/* App data store                                                      */
/* ------------------------------------------------------------------ */
interface AppState {
  page: string;
  navigate: (page: string) => void;
  roadmaps: RoadmapDraft[];
  submissions: Record<string, string>;
  apiKey: string;
  setApiKey: (k: string) => void;
  readNotifs: string[];
  markNotifRead: (id: string) => void;
  saveRoadmap: (r: RoadmapDraft) => void;
  removeRoadmap: (id: string) => void;
  publishRoadmap: (id: string) => void;
  updateTask: (roadmapId: string, dayId: string, taskId: string, patch: Partial<RoadmapTask>) => void;
  submitTask: (taskId: string, text: string) => void;
  setTaskStatus: (taskId: string, status: TaskStatus, extra?: Partial<RoadmapTask>) => void;
  addTask: (roadmapId: string, dayId: string, task: RoadmapTask) => void;
  removeTask: (roadmapId: string, dayId: string, taskId: string) => void;
  moveTask: (roadmapId: string, dayId: string, taskId: string, dir: -1 | 1) => void;
  resetData: () => void;
}

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      page: "dashboard",
      navigate: (page) => set({ page }),
      roadmaps: seedRoadmaps,
      submissions: seedSubmissions,
      apiKey: "",
      setApiKey: (k) => set({ apiKey: k }),
      readNotifs: [],
      markNotifRead: (id) => set((s) => ({ readNotifs: [...new Set([...s.readNotifs, id])] })),
      saveRoadmap: (r) =>
        set((s) => ({
          roadmaps: s.roadmaps.some((x) => x.id === r.id)
            ? s.roadmaps.map((x) => (x.id === r.id ? r : x))
            : [...s.roadmaps, r],
        })),
      removeRoadmap: (id) => set((s) => ({ roadmaps: s.roadmaps.filter((r) => r.id !== id) })),
      publishRoadmap: (id) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) => (r.id === id ? { ...r, status: "published" } : r)),
        })),
      updateTask: (roadmapId, dayId, taskId, patch) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) =>
            r.id !== roadmapId
              ? r
              : { ...r, days: r.days.map((d) => (d.id !== dayId ? d : { ...d, tasks: d.tasks.map((t) => (t.id !== taskId ? t : { ...t, ...patch })) })) },
          ),
        })),
      submitTask: (taskId, text) =>
        set((s) => ({
          submissions: { ...s.submissions, [taskId]: text },
          roadmaps: s.roadmaps.map((r) => ({
            ...r,
            days: r.days.map((d) => ({
              ...d,
              tasks: d.tasks.map((t) => (t.id === taskId ? { ...t, status: "submitted" as TaskStatus, teacherFeedback: undefined } : t)),
            })),
          })),
        })),
      setTaskStatus: (taskId, status, extra) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) => ({
            ...r,
            days: r.days.map((d) => ({
              ...d,
              tasks: d.tasks.map((t) => (t.id === taskId ? { ...t, status, ...extra } : t)),
            })),
          })),
        })),
      addTask: (roadmapId, dayId, task) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) =>
            r.id !== roadmapId ? r : { ...r, days: r.days.map((d) => (d.id !== dayId ? d : { ...d, tasks: [...d.tasks, task] })) },
          ),
        })),
      removeTask: (roadmapId, dayId, taskId) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) =>
            r.id !== roadmapId ? r : { ...r, days: r.days.map((d) => (d.id !== dayId ? d : { ...d, tasks: d.tasks.filter((t) => t.id !== taskId) })) },
          ),
        })),
      moveTask: (roadmapId, dayId, taskId, dir) =>
        set((s) => ({
          roadmaps: s.roadmaps.map((r) => {
            if (r.id !== roadmapId) return r;
            return {
              ...r,
              days: r.days.map((d) => {
                if (d.id !== dayId) return d;
                const i = d.tasks.findIndex((t) => t.id === taskId);
                const j = i + dir;
                if (i < 0 || j < 0 || j >= d.tasks.length) return d;
                const tasks = [...d.tasks];
                [tasks[i], tasks[j]] = [tasks[j], tasks[i]];
                return { ...d, tasks };
              }),
            };
          }),
        })),
      resetData: () => set({ roadmaps: seedRoadmaps, submissions: seedSubmissions, readNotifs: [] }),
    }),
    { name: "studypath-app", partialize: (s) => ({ roadmaps: s.roadmaps, submissions: s.submissions, readNotifs: s.readNotifs, page: s.page }) },
  ),
);

/* ---------------- selectors ---------------- */
export const allTasks = (roadmaps: RoadmapDraft[]) =>
  roadmaps.flatMap((r) => r.days.flatMap((d) => d.tasks.map((t) => ({ roadmap: r, day: d, task: t }))));

export const tasksForStudent = (roadmaps: RoadmapDraft[], studentId: string) =>
  allTasks(roadmaps).filter(({ roadmap, task }) => roadmap.studentId === studentId && task.assignTo.ids.includes(studentId));

export const publishedForStudent = (roadmaps: RoadmapDraft[], studentId: string) =>
  roadmaps.find((r) => r.studentId === studentId && r.status === "published");
