export type Role = "student" | "class_teacher" | "subject_teacher" | "admin";

export interface PerformanceFactors {
  attendancePct: number;
  assessmentAvg: number;
  assignmentAvg: number;
  quizAvg: number;
  laboratory: number;
  internalAssessment: number;
}

export type FactorKey = keyof PerformanceFactors;

export interface Prediction {
  id: string;
  studentId: string;
  predictedPct: number;
  predictedMarks: number;
  maxMarks: number;
  modelVersion: "E46_V1";
  featureSetVersion: string;
  dataStatus: "verified" | "unverified";
  verifiedDataUsed: boolean;
  factors: PerformanceFactors;
  createdAt: string;
}

export type TaskStatus = "not_started" | "submitted" | "verified" | "needs_revision";
export type TaskType = "study" | "quiz" | "assignment" | "practice";
export type TaskPriority = "low" | "medium" | "high";

export interface RoadmapTask {
  id: string;
  title: string;
  description?: string;
  subject: string;
  type: TaskType;
  priority: TaskPriority;
  estimatedMinutes: number;
  dueDate?: string;
  resources?: string[];
  assignTo: { scope: "student" | "selected" | "class"; ids: string[] };
  status: TaskStatus;
  teacherFeedback?: string;
  marks?: { awarded: number; outOf: number };
}

export interface RoadmapDay {
  id: string;
  dayNumber: number;
  title: string;
  tasks: RoadmapTask[];
}

export interface RoadmapDraft {
  id: string;
  studentId: string;
  subject: string;
  predictionId: string;
  priorityFocus: string;
  durationDays: number;
  days: RoadmapDay[];
  status: "draft" | "published";
  source: "manual" | "ai_generated";
  createdAt: string;
}

export interface Student {
  id: string;
  name: string;
  roll: string;
  className: string;
  branch: string;
  semester: number;
  color: string;
  factors: PerformanceFactors;
  subjects: { name: string; grade: string; pct: number }[];
}

export interface TeacherUser {
  id: string;
  name: string;
  role: "class_teacher" | "subject_teacher";
  className?: string;
  subjects: string[];
}

export interface AppNotification {
  id: string;
  audience: Role;
  title: string;
  body: string;
  time: string;
  kind: "info" | "success" | "warning" | "danger";
}

export interface LearningResource {
  id: string;
  title: string;
  subject: string;
  kind: "video" | "notes" | "article" | "problem-set";
  minutes: number;
  locked?: boolean;
  summary: string;
}

export interface AdminRow {
  id: string;
  [key: string]: string | number;
}
